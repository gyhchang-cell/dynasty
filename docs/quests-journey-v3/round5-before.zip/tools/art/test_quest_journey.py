"""Migration checks: old saves, easier goals, live navigation and readable blocks."""
import copy
import json
import re
import unittest
from pathlib import Path
import quest_story as story
import quest_journey as journey

class QuestJourneyTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base=story.build_source_book();cls.book=story.build_book()
        cls.before={q['id']:q for c in cls.base for q in c['quests']}
        cls.after={q['id']:q for c in cls.book for q in c['quests']}

    def test_consolidation_preserves_every_quest_and_reward(self):
        self.assertEqual(20,len(self.book));self.assertGreater(len(self.after),1200)
        self.assertTrue(set(self.before)<=set(self.after))
        for k,q in self.before.items():
            self.assertEqual(q['rewards'],self.after[k]['rewards'])
            self.assertEqual(q['target'],self.after[k]['target'])
        journey.validate(self.book,self.base)

    def test_lowered_goals_keep_task_id_and_detection(self):
        lowered=[q for q in self.after.values() if q.get('journey_previous_count')]
        self.assertGreater(len(lowered),40)
        for q in lowered:
            self.assertLess(q['count'],self.before[q['id']]['count'])
            self.assertEqual(re.findall(r'\bid: "([12][a-f0-9A-F]{15})"',q['tasks']),
                             re.findall(r'\bid: "([12][a-f0-9A-F]{15})"',self.before[q['id']]['tasks']))

    def test_main_story_cannot_acquire_catalog_gate(self):
        for k,q in self.before.items():
            if q['role']=='main':self.assertEqual(q['deps'],self.after[k]['deps'])
        bad=copy.deepcopy(self.book)
        q=next(q for c in bad for q in c['quests'] if q['role']=='main')
        q['deps']=[next(q['id'] for c in bad for q in c['quests'] if q['role']=='tutorial')]
        with self.assertRaises(AssertionError):journey.validate(bad,self.base)

    def test_new_tasks_are_small_and_do_not_farm_rewards(self):
        for q in self.after.values():
            if q.get('journey_new'):
                self.assertEqual(1,q['count']);self.assertEqual('[]',q['rewards'])
                if q['kind']=='item':self.assertIn('consume_items: false',q['tasks'])

    def test_removed_chapter_links_are_redirected(self):
        dead={c['id'] for c in self.base if c['file']+'.snbt' in journey.known_removed()}
        for q in self.after.values():
            for s in q['description']:
                if s.startswith('{"'):self.assertNotIn(json.loads(s)['clickEvent']['value'],dead)

    def test_inline_figures_exist_and_dimensions_are_bounded(self):
        images=[s for q in self.after.values() for s in q['description'] if s.startswith('{image:')]
        self.assertGreaterEqual(len(images),30)
        for s in images:
            self.assertIn('width:220 height:110 align:center',s)
            p=story.ROOT/'src/main/resources/assets'/s.split('image:',1)[1].split(' ',1)[0].replace(':','/',1)
            self.assertTrue(p.is_file())

    def test_layout_has_no_close_or_coincident_nodes(self):
        for c in self.book:
            qs=c['quests']
            for i,q in enumerate(qs):
                for p in qs[i+1:]:
                    self.assertGreaterEqual(max(abs(p['x']-q['x']),abs(p['y']-q['y'])),1.0,c['file'])

    def test_dependency_cycle_rejected(self):
        bad=copy.deepcopy(self.book)
        q=next(q for c in bad for q in c['quests'] if q.get('journey_new'))
        q['deps']=[q['id']]
        with self.assertRaises(AssertionError):journey.validate(bad,self.base)

    def test_prep_steps_match_real_recipe_inputs(self):
        recipes=story.recipe_index()
        for q in self.after.values():
            if q.get('for_quest'):
                target=self.after[q['for_quest']]['target']
                self.assertTrue(any(q['target'] in r['ingredients'] for r in recipes[target]))

    def test_short_tutorials_keep_scene_conditions(self):
        for item,terms in [('puzzle_box',['40秒','潜行']),('ancient_well',['7次','3分钟']),
                           ('mortuary_room',['2分钟','治疗药水']),('ghost_market_boat',['朱砂','2分钟'])]:
            q=next(q for q in self.after.values() if q.get('cod4_item')==item)
            text=' '.join(q['description'])
            for term in terms:self.assertIn(term,text)
            self.assertLess(len(text),220)

    def test_map_card_jump_cannot_point_to_removed_chapter(self):
        bad=copy.deepcopy(self.book)
        c=next(c for c in bad if c['file']=='dynasty_home')
        self.assertEqual(19,len(c['images']))
        c['images'][0]['click']='#'+next(c['id'] for c in self.base if c['file']=='dynasty_accessory_ring')
        with self.assertRaises(AssertionError):journey.validate(bad,self.base)

    def test_secondary_item_in_multi_goal_is_also_reduced(self):
        q=next(q for q in self.after.values() if q['title']=='云台防坠 · 水与搭路石')
        self.assertIn('count: 4L',q['tasks']);self.assertNotIn('count: 64L',q['tasks'])
        self.assertIn('圆石×4',' '.join(q['description']))

if __name__=='__main__':unittest.main()
