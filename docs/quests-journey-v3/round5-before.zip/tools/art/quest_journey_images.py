"""Original code-drawn FTB operation diagrams, based on local game contracts.

These are GUI instruction figures, not entity/item textures or copied pack art.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json,zipfile

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'src/main/resources/assets/dynasty/textures/gui/quests/journey'
FIGURES={
 'altar':('祭坛摆放 · 同一高度', ['玉　空　玉','空　坛　空','玉　空　玉'], ['坛＝法阵·祭坛；玉＝玉石块','手持对应信物，右键中间祭坛']),
 'qimen':('奇门机括 · 无序合成',['精钢 ×1','铜锭 ×1','红石粉 ×1'],['放进合成格 → 奇门机括 ×2','留机括做兵器，再按需补钢索']),
 'bronze':('基础青铜 · 无序合成',['铜锭 ×3','铁锭 ×1','青铜锭 ×4'],['铜与铁放入合成格','箭头右侧是产物数量']),
 'portals':('往返准备 · 门成对带走',['主世界：放第一座','右键进入目标维度','安全处：放第二座'],['对面不会自动造回程门','归乡符回主世界出生点附近']),
 'infusion':('炼物入器 · 操作示意',['装备入槽','材料 ×2','经验 3级'],['选择炼入位并确认；容量3～5','替换或移除看界面；移除耗1级经验']),
 'exam':('科举 · 从试卷到答题',['纸 + 墨囊','合成科举试卷','手持右键答题'],['答对至少一次才算科举中第','仅把试卷放背包不算答题']),
 'army':('虎符 · 从兵册到出阵',['募兵台招募兵员','右键虎符选阵型','确认出阵'],['必须实际召出部队才记录','潜行右键的威慑不算列阵']),
 'compasses':('导航 · 两种罗盘分工',['自然指南针：群系','探险者指南针：建筑','只搜当前维度'],['主手自然指南针 + /dynasty_find','追踪栖息地不保证怪物立即刷新']),
 'curios':('饰品佩戴 · 槽位示意',['打开饰品栏','选择对应分类槽','拖入已获得的饰品'],['放在背包不会生效','万能槽可放不同类别；看属性取舍']),
 'smithing':('兵器进化 · 锻造台',['图纸（模板）','上一阶兵器（底材）','进化材料（添加物）'],['按制作节点配方放入锻造台','升级会消耗底材；保留兵器NBT']),
 'locks':('机关盒 · 朝向与等待',['北站立 → 东潜行','南站立 → 西潜行','前三段各40秒'],['末段至少半秒；总计至少2分钟','方向错会复位，按现场提示操作']),
 'sword_moves':('剑痕石壁 · 晴朗露天夜晚',['朝北向东移，挥剑','朝北向西移，挥剑','向北移，转东挥剑'],['每式间隔40秒，总计至少2分钟','持续持同一把主手剑，别远离石壁']),
 'well':('古井供水 · 一桶可以重用',['装满水桶','供水后返空桶','再装水，重复7次'],['总计至少3分钟，空桶不计','第七次完成后按现场提示取奖励']),
 'boat':('鬼市小舟 · 点香后再交付',['手持安魂香请船夫','询问渡口，等2分钟','手持朱砂再交互'],['给船边留站立空间','完成后取得旧竹简']),
 'rescue':('义庄救人 · 先辨生死',['观察微弱呼吸','等待2分钟','手持治疗药水救助'],['消耗一瓶，返还空瓶','牛奶清自身负面不能代替救人']),
 'bellows':('风箱烧炼 · 三格内',['准备熔炉与待炼物','输出留空，带木炭','等30秒，再次交互'],['也支持烟熏炉与高炉','推动实际烧炼后取得铁粒']),
}

def build():
    OUT.mkdir(parents=True,exist_ok=True)
    font=ImageFont.truetype('/System/Library/Fonts/STHeiti Medium.ttc',18)
    bold=ImageFont.truetype('/System/Library/Fonts/STHeiti Medium.ttc',22)
    for key,(title,cells,notes) in FIGURES.items():
        im=Image.new('RGB',(512,256),'#142628');d=ImageDraw.Draw(im)
        d.rectangle((3,3,508,252),outline='#9dbeaa',width=2)
        d.text((20,16),title,font=bold,fill='#e5d1a0')
        if key=='altar':
            for row in range(3):
                for col in range(3):
                    x=199+col*40;y=54+row*40
                    jade=row!=1 and col!=1;center=row==col==1
                    d.rectangle((x,y,x+36,y+36),fill='#598877' if jade else '#81647c' if center else '#263b3c',outline='#bed2c6')
                    d.text((x+8,y+8),'玉' if jade else '坛' if center else '',font=font,fill='#e8ede2')
        else:
            for i,text in enumerate(cells):
                y=57+i*42
                d.rectangle((20,y,490,y+33),fill='#263b3c',outline='#598877',width=1)
                d.text((32,y+5),f'{i+1}  {text}',font=font,fill='#e8ede2')
        for i,text in enumerate(notes):d.text((20,190+i*24),text,font=font,fill='#bed2c6')
        im.save(OUT/(key+'.png'))
    from quest_story import build_source_book
    from quest_journey import TITLES
    labels=OUT/'labels';labels.mkdir(exist_ok=True)
    for c in build_source_book():
        im=Image.new('RGB',(512,48),'#142628');d=ImageDraw.Draw(im)
        d.rectangle((1,1,510,46),outline='#9dbeaa',width=2)
        title=c['title'].split(' · ')[0]
        import re
        title=re.sub(r'&[0-9a-fk-or]','',title)
        d.text((15,11),title,font=bold,fill='#e5d1a0');im.save(labels/(c['file']+'.png'))
    cards=OUT/'cards';cards.mkdir(exist_ok=True)
    for c in build_source_book():
        im=Image.new('RGB',(512,128),'#142628');d=ImageDraw.Draw(im)
        d.rectangle((2,2,509,125),outline='#9dbeaa',width=3)
        title=re.sub(r'&[0-9a-fk-or]','',TITLES.get(c['file'],c['title']))
        parts=title.split(' · ')
        d.text((20,34),parts[0],font=bold,fill='#e5d1a0')
        d.text((20,73),parts[1] if len(parts)>1 else '点击进入 · 按分区选支线',font=font,fill='#bed2c6')
        im.save(cards/(c['file']+'.png'))
    # Reloadable GUI-only pack lets existing local mod jars load the diagrams.
    pack=ROOT/'modpack/resourcepacks/dynasty-quest-guides-v3.zip';pack.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(pack,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('pack.mcmeta',json.dumps({'pack':{'pack_format':15,'description':'王朝任务 · 原创操作图示'}},ensure_ascii=False))
        for p in OUT.rglob('*.png'):z.write(p,'assets/dynasty/textures/gui/quests/journey/'+str(p.relative_to(OUT)))
    print('Built',len(FIGURES),'original operation figures and GUI resource pack')
if __name__=='__main__':build()
