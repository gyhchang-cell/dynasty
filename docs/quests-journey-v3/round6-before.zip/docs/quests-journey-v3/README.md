# 王朝任务书夜间迭代

截至第5轮：40章合并为20章，808个原任务全部保留，共1262个任务。新增454个小目标/教程；按检测量逐项对照，93个任务降量（92个主检测量、1个搭路石的次检测量）。此前86的统计漏计了7个击杀阶梯任务。

第5轮增加自然指南针和探险者指南针两个真实物品目标、四个独立淬炼操作教程。共18种原创操作图、46处正文引用。399个备料节点补充来源说明，并固定已部署身份，避免新增配方改变排序后丢失两个原节点。

材料页合并重复宝箱/掉落说明，饰品槽位页缩短；淬炼节点保留当前阶段和材料量。原808个任务的可见文字由94,915字减至59,690字；包含全部新增任务后为79,036字。计数包含链接标签，不把JSON语法和图片标记算作玩家看到的文字。

23个远距离前置节点使用悬停显示连线并保留准确的前置点击入口；原依赖条件与主线顺序不变。源码行为核对依据为[FTB Quest](https://github.com/FTBTeam/FTB-Quests/blob/1.20.1/main/common/src/main/java/dev/ftb/mods/ftbquests/quest/Quest.java)和[QuestPanel](https://github.com/FTBTeam/FTB-Quests/blob/1.20.1/main/common/src/main/java/dev/ftb/mods/ftbquests/client/gui/quests/QuestPanel.java)，这部分仍需游戏内检查。

62项测试及物品注册、任务图、导出一致性检查通过。三份现存Dynasty配置和GUI资源包已备份同步，options逐字节保持原样。缺失的旧尾空格版本目录没有重建，愚者世界未关闭，没有启动新的Java程序。

新版真实客户端验收仍待完成：上轮在创建窗口前因GLFW找不到主显示器失败；没有唤醒显示器或反复重试。本轮图示文件检查和源码检查不能替代游戏内图片解析、点击跳转及悬停连线验收。

仍需查实玄鸟神羽、汉白玉、朱红柱的简明生存来源。Cod2等完整玩法要求未因任务书排版或模型完成而验收，本轮未删除原提示词段落。

证据文件：`DELIVERY.json`、`rounds.json`、`round5-tests.txt`、`round5-validation.txt`、`launcher-sync-round5.json`。最新部署快照为`last-deployed-book.json`，续作断点为`night-work.json`。原始及各轮备份不得覆盖。

后续每轮先核对已部署身份，完成具体修改与自检，使用`tools/art/sync_quest_journey.py --round N`同步。同步工具会拒绝已被其他人修改的启动器任务配置，不修改玩家存档或游戏选项。北京时间2026年10月12日09:00后停止新轮次并移除自动化。
