"""Migration checks: old saves, easier goals, live navigation and readable blocks."""
import copy
import json
import re
import unittest
from pathlib import Path
import quest_story as story
import quest_journey as journey

class QuestJourneyTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base=story.build_source_book();cls.book=story.build_book()
        cls.before={q['id']:q for c in cls.base for q in c['quests']}
        cls.after={q['id']:q for c in cls.book for q in c['quests']}

    def test_consolidation_preserves_every_quest_and_reward(self):
        self.assertEqual(20,len(self.book));self.assertGreater(len(self.after),1200)
        self.assertTrue(set(self.before)<=set(self.after))
        for k,q in self.before.items():
            self.assertEqual(q['rewards'],self.after[k]['rewards'])
            self.assertEqual(q['target'],self.after[k]['target'])
        journey.validate(self.book,self.base)

    def test_lowered_goals_keep_task_id_and_detection(self):
        lowered=[q for q in self.after.values() if q.get('journey_previous_count')]
        self.assertGreater(len(lowered),40)
        for q in lowered:
            self.assertLess(q['count'],self.before[q['id']]['count'])
            self.assertEqual(re.findall(r'\bid: "([12][a-f0-9A-F]{15})"',q['tasks']),
                             re.findall(r'\bid: "([12][a-f0-9A-F]{15})"',self.before[q['id']]['tasks']))

    def test_main_story_cannot_acquire_catalog_gate(self):
        for k,q in self.before.items():
            if q['role']=='main':self.assertEqual(q['deps'],self.after[k]['deps'])
        bad=copy.deepcopy(self.book)
        q=next(q for c in bad for q in c['quests'] if q['role']=='main')
        q['deps']=[next(q['id'] for c in bad for q in c['quests'] if q['role']=='tutorial')]
        with self.assertRaises(AssertionError):journey.validate(bad,self.base)

    def test_new_tasks_are_small_and_do_not_farm_rewards(self):
        for q in self.after.values():
            if q.get('journey_new'):
                self.assertEqual(1,q['count']);self.assertEqual('[]',q['rewards'])
                if q['kind']=='item':self.assertIn('consume_items: false',q['tasks'])

    def test_removed_chapter_links_are_redirected(self):
        dead={c['id'] for c in self.base if c['file']+'.snbt' in journey.known_removed()}
        for q in self.after.values():
            for s in q['description']:
                if s.startswith('{"'):self.assertNotIn(json.loads(s)['clickEvent']['value'],dead)

    def test_inline_figures_exist_and_dimensions_are_bounded(self):
        images=[s for q in self.after.values() for s in q['description'] if s.startswith('{image:')]
        self.assertGreaterEqual(len(images),30)
        for s in images:
            self.assertIn('width:220 height:110 align:center',s)
            p=story.ROOT/'src/main/resources/assets'/s.split('image:',1)[1].split(' ',1)[0].replace(':','/',1)
            self.assertTrue(p.is_file())

    def test_layout_has_no_close_or_coincident_nodes(self):
        for c in self.book:
            qs=c['quests']
            for i,q in enumerate(qs):
                for p in qs[i+1:]:
                    self.assertGreaterEqual(max(abs(p['x']-q['x']),abs(p['y']-q['y'])),1.0,c['file'])

    def test_dependency_cycle_rejected(self):
        bad=copy.deepcopy(self.book)
        q=next(q for c in bad for q in c['quests'] if q.get('journey_new'))
        q['deps']=[q['id']]
        with self.assertRaises(AssertionError):journey.validate(bad,self.base)

    def test_prep_steps_match_real_recipe_inputs(self):
        recipes=story.recipe_index()
        for q in self.after.values():
            if q.get('for_quest'):
                target=self.after[q['for_quest']]['target']
                self.assertTrue(any(q['target'] in r['ingredients'] for r in recipes[target]))

    def test_short_tutorials_keep_scene_conditions(self):
        for item,terms in [('puzzle_box',['40秒','潜行']),('ancient_well',['7次','3分钟']),
                           ('mortuary_room',['2分钟','治疗药水']),('ghost_market_boat',['朱砂','2分钟'])]:
            q=next(q for q in self.after.values() if q.get('cod4_item')==item)
            text=' '.join(s for s in q['description'] if not s.startswith('{"'))
            for term in terms:self.assertIn(term,text)
            self.assertLess(len(text),220)

    def test_map_card_jump_cannot_point_to_removed_chapter(self):
        bad=copy.deepcopy(self.book)
        c=next(c for c in bad if c['file']=='dynasty_home')
        self.assertEqual(19,len(c['images']))
        c['images'][0]['click']='#'+next(c['id'] for c in self.base if c['file']=='dynasty_accessory_ring')
        with self.assertRaises(AssertionError):journey.validate(bad,self.base)

    def test_secondary_item_in_multi_goal_is_also_reduced(self):
        q=next(q for q in self.after.values() if q['title']=='云台防坠 · 水与搭路石')
        self.assertIn('count: 4L',q['tasks']);self.assertNotIn('count: 64L',q['tasks'])
        self.assertIn('圆石×4',' '.join(q['description']))

    def test_nightly_additions_keep_deployed_save_identities(self):
        previous=json.loads((journey.DOC/'last-deployed-book.json').read_text())
        journey.validate_forward(self.book,previous)
        bad=copy.deepcopy(self.book)
        q=next(q for c in bad for q in c['quests'] if q.get('for_quest'))
        q['target']='minecraft:dirt'
        with self.assertRaisesRegex(AssertionError,'identity repurposed'):
            journey.validate_forward(bad,previous)
        bad=copy.deepcopy(self.book)
        c=next(c for c in bad if any(q.get('for_quest') for q in c['quests']))
        c['quests'].remove(next(q for q in c['quests'] if q.get('for_quest')))
        with self.assertRaisesRegex(AssertionError,'quest lost'):
            journey.validate_forward(bad,previous)

    def test_preparation_identity_survives_new_cheaper_recipe(self):
        from unittest.mock import patch
        from quest_story import recipe_index
        recipes=copy.deepcopy(recipe_index())
        parent='1000000000030063'
        c=copy.deepcopy(next(c for c in self.base if c['file']=='dynasty_build_guard'))
        target=next(q['target'] for q in c['quests'] if q['id']==parent)
        recipes[target].insert(0,{'id':'new_cheaper','type':'minecraft:crafting_shapeless',
            'ingredients':{'minecraft:dirt':1,'minecraft:stick':1},'output':1})
        with patch('quest_story.recipe_index',return_value=recipes):
            added=journey.preparations(c)
        expected=json.loads(Path(journey.__file__).with_name('quest_journey_preparations.json').read_text())['parents'][parent]
        actual=[q for q in added if q.get('for_quest')==parent]
        self.assertEqual([(q['id'],q['target']) for q in expected],[(q['id'],q['target']) for q in actual])
        section_locked=[q for q in self.after.values() if q.get('for_quest') and q['section']==c['file']]
        self.assertEqual({q['id'] for q in section_locked},{q['id'] for q in added})

    def test_prep_source_hints_are_grounded_and_short(self):
        from quest_journey_help import source_hint
        for q in self.after.values():
            if q.get('for_quest'):
                self.assertTrue(q['source_hint']);self.assertEqual(source_hint(q['target']),q['description'][1])
                self.assertLess(len(q['description'][1]),180)
        self.assertIn('没有朱砂矿',source_hint('dynasty:cinnabar'))
        self.assertIn('Y=-60至-5',source_hint('dynasty:dragon_crystal'))
        self.assertIn('纸',source_hint('dynasty:blueprint'))

    def test_distant_arrows_preserve_gates_and_have_clickable_prerequisites(self):
        hidden=[q for q in self.after.values() if q.get('journey_distant_dependencies')]
        self.assertGreater(len(hidden),10)
        for q in hidden:
            self.assertNotEqual('main',q['role'])
            links={json.loads(s)['clickEvent']['value'] for s in q['description'] if s.startswith('{"')}
            self.assertTrue(set(q['journey_distant_dependencies'])<=links)
            self.assertTrue(set(q['journey_distant_dependencies'])<=set(q['deps']))
            c=next(c for c in self.book if q in c['quests'])
            self.assertIn('hide_dependency_lines: true',story.encode(c))
        bad=copy.deepcopy(self.book)
        q=next(q for c in bad for q in c['quests'] if q.get('journey_distant_dependencies'))
        q['description']=[s for s in q['description'] if not s.startswith('{"')]
        with self.assertRaisesRegex(AssertionError,'Hidden prerequisite'):
            journey.validate(bad,self.base)

    def test_compass_steps_detect_real_items_not_reading(self):
        targets={'naturescompass:naturescompass','explorerscompass:explorerscompass'}
        helpers=[self.after[journey.ident('navigation:'+s)] for s in ('nature','explorer')]
        self.assertEqual(targets,{q['target'] for q in helpers})
        for q in helpers:
            self.assertEqual('item',q['kind']);self.assertEqual('[]',q['rewards'])
            self.assertIn('四角留空',' '.join(q['description']))
        q=self.after['100000000001000b']
        self.assertIn('自然指南针和探险者指南针各1个',' '.join(q['description']))
        self.assertEqual(q['tasks'],self.before[q['id']]['tasks'])

    def test_refining_detail_keeps_actual_stage_and_costs(self):
        for route in ('guard','sword','archer','talisman'):
            guide=self.after[journey.ident('refining:'+route)]
            text=' '.join(guide['description'])
            for term in ('0–9','10–24','25–49','50级','上限64','上限39'):
                self.assertIn(term,text)
            q=next(q for q in self.after.values() if q['target']=='dynasty:refine_'+route+'_30')
            self.assertIn('+30',q['description'][0]);self.assertIn('龙晶×55、玄天玉×37',' '.join(q['description']))
            self.assertLess(sum(len(s) for s in q['description'] if not s.startswith('{')),180)

    def test_repetitive_loot_and_slot_prose_are_compact(self):
        for q in self.after.values():
            self.assertFalse(any(s.startswith(('探索宝箱：','可能掉落：')) for s in q['description']))
            if q['target'].startswith('guide:slot_'):
                self.assertLess(sum(len(s) for s in q['description'] if not s.startswith('{')),140)

    def test_launcher_drift_is_rejected_without_writes(self):
        from tempfile import TemporaryDirectory
        from sync_quest_journey import check_baseline,digest
        with TemporaryDirectory() as folder:
            p=Path(folder)/'data.snbt';p.write_bytes(b'{original: true}')
            expected={'data.snbt':digest(p.read_bytes())}
            check_baseline(Path(folder),expected)
            p.write_bytes(b'{other_developer: true}')
            with self.assertRaisesRegex(AssertionError,'Launcher definitions changed'):
                check_baseline(Path(folder),expected)
            self.assertEqual(b'{other_developer: true}',p.read_bytes())

    def test_merged_chapter_number_does_not_survive_in_prose(self):
        q=self.after['10000000000a0005']
        self.assertIn('《四象试炼与讨伐》',' '.join(q['description']))
        self.assertNotIn('第 09 章',' '.join(q['description']))

if __name__=='__main__':unittest.main()
