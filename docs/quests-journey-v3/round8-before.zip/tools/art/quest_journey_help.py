"""Short source and operation help, derived from the repository's actual data.

These tutorials are optional and rewardless. Reading them never stands in for
an item detector or an advancement, and never adds a gate to the main journey.
"""
import json
import re
from functools import lru_cache

NAMES = {'naturescompass:naturescompass':'自然指南针',
         'explorerscompass:explorerscompass':'探险者指南针',
         'minecraft:glass':'玻璃','minecraft:scute':'鳞甲',
         'minecraft:brewing_stand':'酿造台','minecraft:nether_wart':'下界疣',
         '#minecraft:logs':'原木'}
VANILLA_SOURCES = {
 'iron_ingot':'用石镐或更好的镐采铁矿，把粗铁放熔炉烧炼。',
 'copper_ingot':'用石镐或更好的镐采铜矿，把粗铜放熔炉烧炼。',
 'gold_ingot':'用铁镐或更好的镐采金矿，把粗金放熔炉烧炼。',
 'coal':'用镐采煤矿；木炭可作燃料，但不能替代配方中的煤炭。',
 'oak_planks':'砍橡树取得橡木原木，在合成栏分解为橡木木板。',
 'stick':'把两块木板竖排合成木棍。',
 'paper':'把三根甘蔗横排合成纸。',
 'ink_sac':'在河流或海中找鱿鱼，击败后拾取墨囊。',
 'bamboo':'在丛林寻找竹子，留一根种回营地。',
 'string':'击败蜘蛛取得线；在安全位置交战。',
 'sugar':'把甘蔗放入合成栏制成糖。',
 'wheat':'播种小麦种子，等作物成熟后收获。',
 'glass':'把沙子放入熔炉烧炼。',
 'glass_bottle':'三块玻璃在工作台摆成V形，制成玻璃瓶。',
 'leather':'牛、马等动物可掉皮革；狐皮也有转成皮革的配方。',
 'cobblestone':'用镐开采普通石头；不要使用精准采集。',
 'compass':'四块铁锭放上下左右，中央放红石粉，合成指南针。',
 'apple':'橡树或深色橡树的树叶有概率掉苹果。',
 'cooked_porkchop':'把生猪排放熔炉或烟熏炉烧熟。',
 'bone':'击败骷髅可取得骨头。',
 'feather':'鸡会掉普通羽毛；合成御风符用两根，不必寻找玄鸟神羽。',
 'scute':'幼龟长成成年龟时掉鳞甲；喂海龟海草繁殖，保护海龟蛋。',
 'ender_pearl':'击败末影人有概率掉落；先备好防具和安全退路。',
 'gunpowder':'击败苦力怕可取得火药，别让它爆炸。',
 'amethyst_shard':'寻找紫水晶洞，用镐采完全长成的紫水晶簇。',
 'glowstone_dust':'进入下界后采荧石；出发前备好回程。',
 'nautilus_shell':'钓鱼或击败持有鹦鹉螺壳的溺尸取得。',
 'book':'三张纸和一块皮革合成一本书。',
 'golden_apple':'八块金锭围住一个苹果，合成金苹果。',
}
MATERIAL_SOURCES = {
 'jade':'用铁镐开采主世界地下玉矿，取得玉。',
 'dragon_crystal':'用铁镐在主世界Y=-60至-5开采龙晶矿，取得龙晶。',
 'cinnabar':'主世界神庙、法阵遗迹或帝陵宝箱有概率出朱砂；没有朱砂矿。',
 'bronze_ingot':'铜锭×3＋铁锭×1，无序合成青铜锭×4。',
 'refined_steel':'铁锭×3＋朱砂×1，无序合成精钢×2；也可用蟹甲×1配铁锭×1取得精钢×1。',
 'emperor_bone':'亲自讨伐不死始皇或龙帝取得帝骸骨，普通骷髅不掉。',
 'phoenix_feather':'讨伐凤凰有概率取得凤凰羽。',
 'dragon_scale':'讨伐东海龙王取得龙鳞；先保障水下呼吸。',
 'sky_token':'讨伐九霄天将取得天将令。',
 'sea_token':'讨伐东海龙王取得此信物。',
 'dragon_emperor_seal':'讨伐龙帝取得龙帝印，先留一枚作复战信物。',
 'ancient_stele_rubbing':'带纸到官道驿站，按破损界碑的倒计时交互取得拓片。',
 'marble_block':'在主世界平原、草甸或热带草原找书院，带石镐采白色地面或石栏；直接掉汉白玉，无须精准采集。',
 'crimson_pillar':'书院围墙和廊下的红色立柱可采成朱红柱；用镐较快，无须精准采集。',
 'xuanniao_shenyu':'主世界白天，离出生点至少512格且累计击败100只敌对怪后，有机会遇到玄鸟止戈。进入天象64格内参与，天象开始约20秒后结算；15%取得神羽，非必出。',
}

def display_name(target):
    from quest_story import name
    return NAMES.get(target,name(target))

@lru_cache(maxsize=None)
def source_hint(target):
    from quest_story import recipe_index,loot_index
    from quest_cod4 import WILDS
    namespace,short=target.split(':',1)
    if namespace=='minecraft' and short in VANILLA_SOURCES:
        return VANILLA_SOURCES[short]
    if namespace=='dynasty' and short in MATERIAL_SOURCES:
        return MATERIAL_SOURCES[short]
    if namespace=='dynasty' and short in WILDS:
        return '主世界寻找'+WILDS[short][0]+'，掉落有概率。'
    # Prefer normal recipes to recoveries or alternate end-game conversions.
    recipes=recipe_index().get(target,[])
    if recipes:
        r=min(recipes,key=lambda r:(r['id'].startswith(('recover_','cod4/','branch_')),r['id']))
        parts=['或'.join(display_name(v) for v in k.split(' / '))+'×'+str(n)
               for k,n in r['ingredients'].items()]
        method='锻造台' if r['type']=='minecraft:smithing_transform' else '烧炼' if r['type'] in {'minecraft:smelting','minecraft:blasting'} else '合成'
        return method+'：'+'＋'.join(parts)+' → '+display_name(target)+'×'+str(r['output'])+'。'
    chests=[name for kind,name in loot_index().get(target,[]) if kind=='chests' and re.search('[\u4e00-\u9fff]',name)]
    if chests:return '探索'+ '、'.join(chests[:2])+'宝箱，有概率取得。'
    enemies=[name for kind,name in loot_index().get(target,[]) if kind=='entities']
    if enemies:return '来源：'+ '、'.join(dict.fromkeys(enemies))+'的掉落。'
    # Use the already-audited item's own event guide rather than invent a recipe.
    return '在物品用途页查看来源；没有核实配方的收藏不作为主线门槛。'

def simplify(q):
    from quest_journey import ASSET,clean
    lines=q['description'];target=q['target']
    # One short loot line avoids a wall of repetitive chest/entity names.
    sources=[s for s in lines if s.startswith(('探索宝箱：','可能掉落：'))]
    if sources:
        chests=[];enemies=[]
        for s in sources:
            label=s.split('：',1)[1].split('（',1)[0]
            if not re.search('[\u4e00-\u9fff]',label):continue
            (chests if s.startswith('探索') else enemies).append(label)
        hint=[]
        if chests:hint.append('宝箱：'+'、'.join(list(dict.fromkeys(chests))[:3]))
        # Optional sources need not invite attacks on friendly NPCs.
        enemies=[x for x in enemies if x not in {'麒麟','大臣','帝国士兵','锦衣卫'}]
        if enemies:hint.append('掉落：'+'、'.join(list(dict.fromkeys(enemies))[:2]))
        first=next(i for i,s in enumerate(lines) if s in sources)
        q['description']=[s for s in lines if s not in sources]
        if hint:q['description'].insert(first,'；'.join(hint)+'（概率取得）。')
    if target.startswith('guide:slot_'):
        slot=clean(q['title']).split(' · ')[0]
        refs=[s for s in q['description'] if s.startswith('{"')]
        q['description']=[f'打开物品栏的Curios面板，把饰品拖进{slot}槽或万能槽。',
            '佩戴才生效；先看悬浮说明的代价、昼夜、水下或残血条件。',
            '收藏节点只检测持有。这一页读完可勾选，无须收齐本区。',*refs,
            f'{{image:{ASSET}curios.png width:220 height:110 align:center}}']
    if re.fullmatch(r'dynasty:refine_[a-z]+_\d+',target):
        stage=target.rsplit('_',1)[1]
        important=[s for s in q['description'] if s.startswith('本段 ') or '额外伤害：' in s]
        q['description']=[f'&e持有或佩戴本流派淬炼达到+{stage}的饰品。',
            '铁砧左槽放一件饰品，右槽放当前材料；逐级取出结果。',
            *important,'经验按每次操作扣等级；材料不足时先做较低阶段。']
    if target in NAMES:
        q['description']=[s.replace(target,NAMES[target]).replace('#minecraft:logs','原木') for s in q['description']]
    if q.get('for_quest'):
        q['description']=[q['description'][0],source_hint(target)]
        q['source_hint']=True
        q['subtitle']='备料 · 持有一份即可'
    elif target in {'dynasty:marble_block','dynasty:crimson_pillar'}:
        q['description'].append(source_hint(target))
        q['description'].append(f'{{image:{ASSET}academy_materials.png width:220 height:110 align:center}}')
    if target=='dynasty:xuanniao_shenyu' and q.get('for_quest'):
        q.update(title='可选 · 玄鸟神羽',display_title='可选 · 玄鸟神羽',subtitle='吉兆事件 · 概率收藏')
        q['description'][0]='持有玄鸟神羽×1，可配符纸制成两张御风符。主线可用普通羽毛配方。'
    if target=='dynasty:wind_talisman':
        q['description']=[q['description'][0],
            '无序合成：符纸×1＋普通羽毛×2＋丝绸×1 → 御风符×1。',
            '右键使用：45秒缓降、速度III、跳跃提升II，并推开周围敌人；到期前回到安全平台。',
            f'{{image:{ASSET}wind_recipe.png width:220 height:110 align:center}}']
    if target=='dynasty:altar':
        from boss_quest_guides import jump
        q.update(title='祭坛 · 建筑装饰',display_title='祭坛 · 建筑装饰')
        q['description'].extend(['这是装饰祭坛；召唤Boss使用另一种“法阵·祭坛”。',
            jump('法阵祭坛 · 摆放与信物','1000000000020006')])
    # Cod6 changes the serialized detector to army_clear, while keeping the old
    # kind/target/save identity. Prose must follow that actual detector.
    army=re.search(r'advancement: "dynasty:army_clear_([a-z_]+)"',q['tasks'])
    if army:
        from boss_quest_guides import jump
        from quest_journey import ident
        boss=display_name('dynasty:'+army[1]);milestone=q['id']=='100000000000014b'
        q.update(title='军阵 · '+boss,display_title='军阵 · '+boss)
        q['description']=['&e完成'+boss+'军阵关卡。',
            '科举中第后，在募兵台用银币购兵。手持虎符选关卡，入场后编队、出阵，再点开战。',
            '开战至少部署1名士兵。关卡结算胜利才记录；野外击杀不算本节点，战损会保留。',
            jump('首领招式应对',ident('boss:'+army[1]+':应对')),
            f'{{image:{ASSET}army_stage.png width:220 height:110 align:center}}']
        if milestone:q['description'].insert(3,'首次领取本节点奖励：永久增加1个万能饰品槽。')
    # Keep stage effects and one actual smithing recipe; remove duplicate prose.
    if q.get('route') and q.get('subtitle')=='进阶饰品':
        from boss_quest_guides import jump
        from quest_journey import ident
        recipe=next((s for s in q['description'] if '→' in s),None)
        q['description']=[q['description'][0],q['purpose']+'。',
            '锻造台升级；佩戴才生效，保留淬炼、附魔和名称。',
            *([recipe] if recipe else []),
            jump('饰品淬炼操作',ident('refining:'+q['route']))]
    visits={
        'dynasty:story_visit_yunqi_manor':('进入主世界云栖庄园。',
            '用探险者指南针搜索云栖庄园，在新生成区块寻找。进入建筑范围自动记录，无须提交建筑材料。'),
        'dynasty:visit_ruined_battlefield':('进入主世界焦土古战场。',
            '用探险者指南针搜索焦土古战场，在新生成区块寻找。进入残营即可记录；夜间会有军兵，先留退路。'),
        'dynasty:story_visit_longque_sanctuary':('进入主世界龙阙。',
            '击败龙帝后，用探险者指南针搜索龙阙。进入巨龙头建筑范围自动记录；供台位于龙嘴内。'),
    }
    if target in visits:
        goal,details=visits[target]
        refs=[s for s in q['description'] if s.startswith('{"')]
        if target=='dynasty:story_visit_longque_sanctuary':
            for i,s in enumerate(refs):
                link=json.loads(s)
                if '青龙' in link.get('text',''):
                    link['text']='《四象试炼与讨伐》 · 青龙供台'
                    refs[i]=json.dumps(link,ensure_ascii=False)
        q['description']=['&e'+goal,details,*refs,
            f'{{image:{ASSET}compasses.png width:220 height:110 align:center}}']
    if target=='dynasty:dynasty_potion':
        q.update(title='王朝药水 · 旧藏记录',display_title='王朝药水 · 旧藏记录',subtitle='历史收藏 · 可跳过')
        q['description']=['旧版本药水的收藏记录。生存酿造请看“酿造入门”，此项不要求完成。']
    # Known ingredient display names should not leak resource IDs into instructions.
    q['description']=[s if s.startswith('{') else re.sub(r'\b(?:dynasty|minecraft):[a-z_]+',
        lambda m:display_name(m[0]),s) for s in q['description']]
    # Empty editorial headings and travel-next-step boilerplate are not objectives.
    q['description']=[s for s in q['description'] if clean(s) not in {'顺路可做','选择 Boss 查看地点与打法'}
                      and not s.startswith(('林地、河岸、矿洞与夜行四路','备军粮和锦囊；'))]
    q['description']=[s.replace('第 09 章四象镇渊','《四象试炼与讨伐》')
        .replace('第 09 章 · 从青龙贡品路线开始','四象试炼与讨伐 · 青龙路线') for s in q['description']]

def add_operation_steps(chapters):
    from quest_journey import node,ASSET
    from boss_quest_guides import jump
    byfile={c['file']:c for c in chapters}
    c=byfile['dynasty_story_02']
    original=next(q for q in c['quests'] if q['id']=='100000000001000b')
    helpers=[]
    for key,target,title,description in [
      ('nature','naturescompass:naturescompass','自然指南针 · 找群系',[
        '工作台中央放指南针，上下左右各放一块原木，四角留空。',
        '合成后右键，选择群系并开始搜索；先进入目标维度。']),
      ('explorer','explorerscompass:explorerscompass','探险者指南针 · 找建筑',[
        '工作台中央放指南针，上下左右各放一块圆石，四角留空。',
        '合成后右键，选择建筑并开始搜索；找建筑不保证怪物立刻刷新。'])]:
        q=node('navigation:'+key,title,target,deps=list(original['deps']),description=[
            '&e取得并持有'+display_name(target)+'×1。',*description,
            f'{{image:{ASSET}compass_recipe.png width:220 height:110 align:center}}'])
        q['section']=c['file'];helpers.append(q)
    c['quests'].extend(helpers)
    original.update(title='两种罗盘 · 备齐导航',display_title='两种罗盘 · 备齐导航')
    original['description']=['&e同时持有自然指南针和探险者指南针各1个。',
        '领取上一节点的两个指南针，按两种配方分别制作；不收走物品。',
        *[jump(q['title'],q['id']) for q in helpers],
        f'{{image:{ASSET}compasses.png width:220 height:110 align:center}}']
    # A normal-material lane is easier than waiting for the rare celestial event.
    # Keep the existing main detector and the saved rare-feather detector intact.
    c=byfile['dynasty_story_06']
    wind=next(q for q in c['quests'] if q['id']=='1000000000010026')
    previous=None;materials=[]
    for key,target,title,details in [
        ('feather','minecraft:feather','御风备料 · 普通羽毛',[
            source_hint('minecraft:feather')]),
        ('silk','dynasty:silk','御风备料 · 丝绸',[
            '线×3合成生丝×1，生丝×3合成丝绸×1；从头制作需要线×9。']),
        ('paper','dynasty:talisman_paper','御风备料 · 符纸',[
            source_hint('dynasty:talisman_paper'),source_hint('dynasty:cinnabar')])]:
        q=node('wind-material:'+key,title,target,
            deps=[previous] if previous else list(wind['deps']),
            description=['&e取得'+display_name(target)+'×1，背包持有即可。',*details])
        q['section']=c['file'];q['subtitle']='普通配方 · 备料';q['journey_operation']='wind_material'
        materials.append(q);previous=q['id']
    c['quests'].extend(materials)
    wind['description'].extend([jump('普通材料 · 羽毛、丝绸、符纸',materials[0]['id']),
        jump('可选事件配方 · 玄鸟神羽','10d388e6188a3f8e')])
    # Teach the working vanilla base process with real item/NBT objectives.
    # Do not substitute a vanilla bottle for the saved legacy dynasty_potion ID.
    c=byfile['dynasty_c2'];previous=None;brewing=[]
    for key,target,title,details,potion in [
        ('stand','minecraft:brewing_stand','酿造入门 · 酿造台',[
            '工作台下排圆石×3，中间一根烈焰棒，合成酿造台。烈焰棒来自下界要塞的烈焰人。'],None),
        ('fuel','minecraft:blaze_powder','酿造入门 · 燃料',[
            '烈焰棒×1可分解成烈焰粉×2。把一份烈焰粉放酿造台左侧燃料槽。'],None),
        ('wart','minecraft:nether_wart','酿造入门 · 下界疣',[
            '在下界要塞的灵魂沙上收集下界疣。它是上方酿造材料，不是燃料。'],None),
        ('water','minecraft:potion','酿造入门 · 水瓶',[
            '用玻璃瓶右键水源装水。下方三个瓶槽放1瓶也能酿造，不必放满。'],'minecraft:water'),
        ('awkward','minecraft:potion','酿造入门 · 粗制药水',[
            '下方放水瓶，上方放下界疣，左侧有烈焰粉；等酿造完成，取出一瓶粗制的药水。',
            '本步检测粗制的药水，普通水瓶或其他药水不算。'],'minecraft:awkward')]:
        label='水瓶' if key=='water' else '粗制的药水' if key=='awkward' else display_name(target)
        q=node('brewing:'+key,title,target,deps=[previous] if previous else [],
            description=['&e取得'+label+'×1，背包持有即可。',*details])
        q['subtitle']='酿造支线 · 持有检测';q['section']=c['file'];q['journey_operation']='brewing'
        if potion:
            stack='{ id: "minecraft:potion", Count: 1b, tag: { Potion: "'+potion+'" } }'
            q['icon']=stack;q['journey_potion']=potion
            q['tasks']='[{ id: "2'+q['id'][1:]+'", type: "item", item: '+stack+', count: 1L, consume_items: false, match_nbt: true, weak_nbt_match: true }]'
        if key=='awkward':q['description'].append(f'{{image:{ASSET}brewing.png width:220 height:110 align:center}}')
        brewing.append(q);previous=q['id']
    c['quests'].extend(brewing)
    legacy=next(q for q in c['quests'] if q['target']=='dynasty:dynasty_potion')
    legacy['description'].append(jump('酿造入门 · 实际制作路线',brewing[0]['id']))
    for route in ('guard','sword','archer','talisman'):
        c=byfile['dynasty_build_'+route]
        q=node('refining:'+route,'饰品淬炼 · 铁砧操作','guide:refining:'+route,kind='checkmark',description=[
            '左槽放单件饰品，右槽放材料。每次取出结果升一级。',
            '当前0–9级用玉；10–24用龙晶；25–49用玄天玉；50级起用天将令。',
            '每次材料：1＋当前等级÷4向下取整，上限64；经验：2＋当前等级，上限39级。',
            '本页是阅读教程；各淬炼目标检测本流派饰品。佩戴才生效，锻造进化保留淬炼。',
            f'{{image:{ASSET}refining.png width:220 height:110 align:center}}'])
        q['icon']='{ id: "minecraft:anvil" }';q['section']=c['file']
        c['quests'].append(q)
        for old in c['quests']:
            if old['target'].startswith('dynasty:refine_'+route+'_'):
                old['description'].append(jump('铁砧操作与逐级材料',q['id']))

def quiet_long_connections(chapters):
    """Hover-reveal distant prerequisites, with exact clickable prerequisite links.

    FTB 1.20.1 QuestPanel.drawConnections preserves the real dependency graph
    while hide_dependency_lines limits default drawing. Main spine stays visible.
    """
    from quest_journey import clean
    from boss_quest_guides import jump
    import math
    for c in chapters:
        local={q['id']:q for q in c['quests']}
        for q in c['quests']:
            if q['role']=='main':continue
            distant=[d for d in q['deps'] if d in local and (
                local[d].get('section')!=q.get('section') or
                math.dist((local[d]['x'],local[d]['y']),(q['x'],q['y']))>12)]
            if not distant:continue
            q['hide_dependency_lines']=True
            q['description'].extend(jump('前置 · '+clean(local[d]['title']),d) for d in q['deps'] if d in local)
            q['journey_distant_dependencies']=distant
