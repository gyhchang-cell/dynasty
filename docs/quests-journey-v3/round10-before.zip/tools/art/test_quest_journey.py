"""Migration checks: old saves, easier goals, live navigation and readable blocks."""
import copy
import json
import re
import unittest
from pathlib import Path
import quest_story as story
import quest_journey as journey

class QuestJourneyTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base=story.build_source_book();cls.book=story.build_book()
        cls.before={q['id']:q for c in cls.base for q in c['quests']}
        cls.after={q['id']:q for c in cls.book for q in c['quests']}

    def test_consolidation_preserves_every_quest_and_reward(self):
        self.assertEqual(20,len(self.book));self.assertGreater(len(self.after),1200)
        self.assertTrue(set(self.before)<=set(self.after))
        for k,q in self.before.items():
            self.assertEqual(q['rewards'],self.after[k]['rewards'])
            self.assertEqual(q['target'],self.after[k]['target'])
        journey.validate(self.book,self.base)

    def test_lowered_goals_keep_task_id_and_detection(self):
        lowered=[q for q in self.after.values() if q.get('journey_previous_count')]
        self.assertGreater(len(lowered),40)
        for q in lowered:
            self.assertLess(q['count'],self.before[q['id']]['count'])
            self.assertEqual(re.findall(r'\bid: "([12][a-f0-9A-F]{15})"',q['tasks']),
                             re.findall(r'\bid: "([12][a-f0-9A-F]{15})"',self.before[q['id']]['tasks']))

    def test_main_story_cannot_acquire_catalog_gate(self):
        for k,q in self.before.items():
            if q['role']=='main':self.assertEqual(q['deps'],self.after[k]['deps'])
        bad=copy.deepcopy(self.book)
        q=next(q for c in bad for q in c['quests'] if q['role']=='main')
        q['deps']=[next(q['id'] for c in bad for q in c['quests'] if q['role']=='tutorial')]
        with self.assertRaises(AssertionError):journey.validate(bad,self.base)

    def test_new_tasks_are_small_and_do_not_farm_rewards(self):
        for q in self.after.values():
            if q.get('journey_new'):
                self.assertEqual(1,q['count']);self.assertEqual('[]',q['rewards'])
                if q['kind']=='item':self.assertIn('consume_items: false',q['tasks'])

    def test_removed_chapter_links_are_redirected(self):
        dead={c['id'] for c in self.base if c['file']+'.snbt' in journey.known_removed()}
        for q in self.after.values():
            for s in q['description']:
                if s.startswith('{"'):self.assertNotIn(json.loads(s)['clickEvent']['value'],dead)

    def test_inline_figures_exist_and_dimensions_are_bounded(self):
        images=[s for q in self.after.values() for s in q['description'] if s.startswith('{image:')]
        self.assertGreaterEqual(len(images),30)
        for s in images:
            self.assertIn('width:220 height:110 align:center',s)
            p=story.ROOT/'src/main/resources/assets'/s.split('image:',1)[1].split(' ',1)[0].replace(':','/',1)
            self.assertTrue(p.is_file())

    def test_layout_has_no_close_or_coincident_nodes(self):
        for c in self.book:
            qs=c['quests']
            for i,q in enumerate(qs):
                for p in qs[i+1:]:
                    self.assertGreaterEqual(max(abs(p['x']-q['x']),abs(p['y']-q['y'])),1.0,c['file'])

    def test_visible_arrows_do_not_pass_through_unrelated_buttons(self):
        from quest_layout_geometry import audit
        for c in self.book:
            result=audit(c)
            self.assertEqual([],result['button_penetrations'],c['file'])
            self.assertEqual([],result['edge_crossings'],c['file'])

    def test_layout_keeps_recipe_steps_adjacent_and_ordered(self):
        for c in self.book:
            if c['main']:continue
            lanes={}
            for q in c['quests']:
                if q.get('for_quest'):lanes.setdefault(q['for_quest'],[]).append(q)
            for parent,preps in lanes.items():
                lane=preps+[self.after[parent]]
                for a,b in zip(lane,lane[1:]):
                    self.assertAlmostEqual(a['y'],b['y'])
                    self.assertAlmostEqual(1.65,b['x']-a['x'])

    def test_mechanical_branches_are_visible_below_their_prerequisites(self):
        # Regression: the old packed row made gear arrows pass through arrows
        # and an infusion tutorial, falsely suggesting a shared crafting chain.
        chain=['1000000000c40002','1000000000c40001','1000000000c40003',
               '1000000000c40004','1000000000c4000c']
        for a,b in zip(chain,chain[1:]):
            self.assertGreater(self.after[b]['y'],self.after[a]['y'])
            self.assertFalse(self.after[b].get('hide_dependency_lines',False))

    def test_obscured_prerequisites_keep_their_real_detector_and_click_target(self):
        affected=[q for q in self.after.values() if q.get('journey_obscured_dependencies')]
        self.assertGreater(len(affected),10)
        for q in affected:
            self.assertNotEqual('main',q['role'])
            links={json.loads(s).get('clickEvent',{}).get('value')
                   for s in q['description'] if s.startswith('{"')}
            self.assertTrue(set(q['journey_obscured_dependencies']) <= links)
            self.assertTrue(q['hide_dependency_lines'])
        snapshot=json.loads((journey.DOC/'last-deployed-book.json').read_text())
        journey.validate_forward(self.book,snapshot)
        for c in snapshot:
            for old in c['quests']:
                self.assertEqual(old['deps'],self.after[old['id']]['deps'])
                if old['role']=='main':
                    self.assertEqual((old['x'],old['y']),
                                     (self.after[old['id']]['x'],self.after[old['id']]['y']))

    def test_visible_titles_do_not_leak_resource_ids(self):
        for q in self.after.values():
            for field in ('title','display_title'):
                self.assertNotRegex(q.get(field,''),r'\b[a-z_]+:[a-z_]+',q['id'])

    def test_chinese_adjacent_resource_ids_are_translated_in_visible_prose(self):
        for q in self.after.values():
            for line in q['description']:
                text=json.loads(line).get('text','') if line.startswith('{"') else '' if line.startswith('{image:') else line
                # No Unicode word-boundary: Chinese + Latin are both word chars.
                self.assertNotRegex(text,r'(?:minecraft|dynasty|naturescompass|explorerscompass):[a-z0-9_/]+',q['id'])

    def test_lowered_counts_match_kill_titles_and_only_one_goal_line(self):
        q=self.after['1000000000030207']
        self.assertIn('value: 3L',q['tasks']);self.assertIn('3名骷髅',q['title'])
        goals=[journey.clean(s) for s in q['description'] if s.startswith(('&e击败','击败'))]
        self.assertEqual(['击败骷髅×3。'],goals)
        for q in self.after.values():
            detector=re.search(r'type:\s*"kill"[^}]*entity:\s*"([^"]+)"[^}]*value:\s*(\d+)L',q['tasks'])
            if detector and q['target'] not in {'dynasty:royal_guard','dynasty:imperial_soldier','dynasty:jade_guard'}:
                goals=[s for s in q['description'] if s.startswith('&e击败')]
                self.assertEqual(1,len(goals),q['id'])
                self.assertIn('×'+detector[2]+'。',goals[0])

    def test_quantity_text_cleanup_does_not_restore_attacking_friendly_troops(self):
        for q in self.after.values():
            if q['target'] in {'dynasty:royal_guard','dynasty:imperial_soldier','dynasty:jade_guard'} and q['kind']=='kill':
                self.assertIn('无需主动攻击',' '.join(q['description']))
                self.assertFalse(any(s.startswith('&e击败') for s in q['description']))

    def test_bottle_and_target_tutorials_use_vanilla_recipes_without_new_old_gates(self):
        recipes=json.loads((journey.DOC/'round9-vanilla-recipes.json').read_text())['recipes']
        self.assertEqual(['# #',' # '],recipes['glass_bottle']['pattern'])
        self.assertEqual(3,recipes['glass_bottle']['result']['count'])
        self.assertEqual([' R ','RHR',' R '],recipes['target']['pattern'])
        self.assertEqual(9,len(recipes['hay_block']['ingredients']))
        bottles=[self.after[journey.ident('bottle-material:'+key)] for key in ('glass','bottle')]
        self.assertEqual(['minecraft:glass','minecraft:glass_bottle'],[q['target'] for q in bottles])
        self.assertEqual([bottles[0]['id']],bottles[1]['deps'])
        target_materials=[self.after[journey.ident('target-material:'+key)] for key in ('wheat','hay','redstone')]
        self.assertEqual(['minecraft:wheat','minecraft:hay_block','minecraft:redstone'],[q['target'] for q in target_materials])
        for i,q in enumerate(target_materials):
            self.assertEqual([target_materials[i-1]['id']] if i else [],q['deps'])
        for q in bottles+target_materials:
            self.assertIn('type: "item"',q['tasks']);self.assertIn('count: 1L',q['tasks'])
            self.assertIn('consume_items: false',q['tasks']);self.assertEqual('[]',q['rewards'])
        target=self.after['1000000000030208'];text=' '.join(target['description'])
        self.assertIn('标靶×1',target['title']);self.assertIn('不检测搭建或命中',text)
        self.assertIn('target_recipe.png',text)
        water=self.after[journey.ident('brewing:water')]
        self.assertNotIn(bottles[1]['id'],water['deps'])
        self.assertNotIn(target_materials[-1]['id'],target['deps'])
        self.assertIn('玻璃瓶×3',' '.join(bottles[1]['description']))

    def test_native_qa_manifest_has_matching_page_names_ids_and_current_counts(self):
        # Caught a source-only QA bug: appending two PAGES without two NAMES
        # would fail after the original twelve screenshots when display returns.
        source=(story.ROOT/'tools/art/quest-integration-qa/com/dynasty/client/QuestIntegrationQa.java').read_text()
        pages=re.search(r'long\[\] PAGES=\{([^}]+)\}',source)[1]
        names=re.search(r'String\[\] NAMES=\{([^}]+)\}',source)[1]
        ids=[format(int(v,16),'016x') for v in re.findall(r'0x([a-f0-9]+)L',pages)]
        labels=re.findall(r'"([^"]+)"',names)
        plan=json.loads((journey.DOC/'native-plan.json').read_text())
        self.assertEqual(plan,[list(pair) for pair in zip(labels,ids)])
        self.assertEqual(len(ids),len(labels))
        live=set(self.after)|{c['id'] for c in self.book}
        self.assertTrue(set(ids)<=live)
        expected=json.loads((journey.DOC/'native-expectations.json').read_text())
        self.assertEqual(len(self.after),expected['quests'])
        self.assertIn('quests=='+str(len(self.after)),source)
        from quest_journey_images import FIGURES
        self.assertEqual(len(FIGURES),expected['operation_figures'])
        self.assertIn('figures=='+str(len(FIGURES)),source)

    def test_dependency_cycle_rejected(self):
        bad=copy.deepcopy(self.book)
        q=next(q for c in bad for q in c['quests'] if q.get('journey_new'))
        q['deps']=[q['id']]
        with self.assertRaises(AssertionError):journey.validate(bad,self.base)

    def test_prep_steps_match_real_recipe_inputs(self):
        recipes=story.recipe_index()
        for q in self.after.values():
            if q.get('for_quest'):
                target=self.after[q['for_quest']]['target']
                self.assertTrue(any(q['target'] in r['ingredients'] for r in recipes[target]))

    def test_short_tutorials_keep_scene_conditions(self):
        for item,terms in [('puzzle_box',['40秒','潜行']),('ancient_well',['7次','3分钟']),
                           ('mortuary_room',['2分钟','治疗药水']),('ghost_market_boat',['朱砂','2分钟'])]:
            q=next(q for q in self.after.values() if q.get('cod4_item')==item)
            text=' '.join(s for s in q['description'] if not s.startswith('{"'))
            for term in terms:self.assertIn(term,text)
            self.assertLess(len(text),220)

    def test_map_card_jump_cannot_point_to_removed_chapter(self):
        bad=copy.deepcopy(self.book)
        c=next(c for c in bad if c['file']=='dynasty_home')
        self.assertEqual(19,len(c['images']))
        c['images'][0]['click']='#'+next(c['id'] for c in self.base if c['file']=='dynasty_accessory_ring')
        with self.assertRaises(AssertionError):journey.validate(bad,self.base)

    def test_secondary_item_in_multi_goal_is_also_reduced(self):
        q=next(q for q in self.after.values() if q['title']=='云台防坠 · 水与搭路石')
        self.assertIn('count: 4L',q['tasks']);self.assertNotIn('count: 64L',q['tasks'])
        self.assertIn('圆石×4',' '.join(q['description']))

    def test_nightly_additions_keep_deployed_save_identities(self):
        previous=json.loads((journey.DOC/'last-deployed-book.json').read_text())
        journey.validate_forward(self.book,previous)
        bad=copy.deepcopy(self.book)
        q=next(q for c in bad for q in c['quests'] if q.get('for_quest'))
        q['target']='minecraft:dirt'
        with self.assertRaisesRegex(AssertionError,'identity repurposed'):
            journey.validate_forward(bad,previous)
        bad=copy.deepcopy(self.book)
        c=next(c for c in bad if any(q.get('for_quest') for q in c['quests']))
        c['quests'].remove(next(q for q in c['quests'] if q.get('for_quest')))
        with self.assertRaisesRegex(AssertionError,'quest lost'):
            journey.validate_forward(bad,previous)

    def test_preparation_identity_survives_new_cheaper_recipe(self):
        from unittest.mock import patch
        from quest_story import recipe_index
        recipes=copy.deepcopy(recipe_index())
        parent='1000000000030063'
        c=copy.deepcopy(next(c for c in self.base if c['file']=='dynasty_build_guard'))
        target=next(q['target'] for q in c['quests'] if q['id']==parent)
        recipes[target].insert(0,{'id':'new_cheaper','type':'minecraft:crafting_shapeless',
            'ingredients':{'minecraft:dirt':1,'minecraft:stick':1},'output':1})
        with patch('quest_story.recipe_index',return_value=recipes):
            added=journey.preparations(c)
        expected=json.loads(Path(journey.__file__).with_name('quest_journey_preparations.json').read_text())['parents'][parent]
        actual=[q for q in added if q.get('for_quest')==parent]
        self.assertEqual([(q['id'],q['target']) for q in expected],[(q['id'],q['target']) for q in actual])
        section_locked=[q for q in self.after.values() if q.get('for_quest') and q['section']==c['file']]
        self.assertEqual({q['id'] for q in section_locked},{q['id'] for q in added})

    def test_prep_source_hints_are_grounded_and_short(self):
        from quest_journey_help import source_hint
        for q in self.after.values():
            if q.get('for_quest'):
                self.assertTrue(q['source_hint']);self.assertEqual(source_hint(q['target']),q['description'][1])
                self.assertLess(len(q['description'][1]),180)
        self.assertIn('没有朱砂矿',source_hint('dynasty:cinnabar'))
        self.assertIn('Y=-60至-5',source_hint('dynasty:dragon_crystal'))
        self.assertIn('纸',source_hint('dynasty:blueprint'))

    def test_distant_arrows_preserve_gates_and_have_clickable_prerequisites(self):
        hidden=[q for q in self.after.values() if q.get('journey_distant_dependencies')]
        self.assertGreater(len(hidden),10)
        for q in hidden:
            self.assertNotEqual('main',q['role'])
            links={json.loads(s)['clickEvent']['value'] for s in q['description'] if s.startswith('{"')}
            self.assertTrue(set(q['journey_distant_dependencies'])<=links)
            self.assertTrue(set(q['journey_distant_dependencies'])<=set(q['deps']))
            c=next(c for c in self.book if q in c['quests'])
            self.assertIn('hide_dependency_lines: true',story.encode(c))
        bad=copy.deepcopy(self.book)
        q=next(q for c in bad for q in c['quests'] if q.get('journey_distant_dependencies'))
        q['description']=[s for s in q['description'] if not s.startswith('{"')]
        with self.assertRaisesRegex(AssertionError,'Hidden prerequisite'):
            journey.validate(bad,self.base)

    def test_compass_steps_detect_real_items_not_reading(self):
        targets={'naturescompass:naturescompass','explorerscompass:explorerscompass'}
        helpers=[self.after[journey.ident('navigation:'+s)] for s in ('nature','explorer')]
        self.assertEqual(targets,{q['target'] for q in helpers})
        for q in helpers:
            self.assertEqual('item',q['kind']);self.assertEqual('[]',q['rewards'])
            self.assertIn('四角留空',' '.join(q['description']))
        q=self.after['100000000001000b']
        self.assertIn('自然指南针和探险者指南针各1个',' '.join(q['description']))
        self.assertEqual(q['tasks'],self.before[q['id']]['tasks'])

    def test_refining_detail_keeps_actual_stage_and_costs(self):
        for route in ('guard','sword','archer','talisman'):
            guide=self.after[journey.ident('refining:'+route)]
            text=' '.join(guide['description'])
            for term in ('0–9','10–24','25–49','50级','上限64','上限39'):
                self.assertIn(term,text)
            q=next(q for q in self.after.values() if q['target']=='dynasty:refine_'+route+'_30')
            self.assertIn('+30',q['description'][0]);self.assertIn('龙晶×55、玄天玉×37',' '.join(q['description']))
            self.assertLess(sum(len(s) for s in q['description'] if not s.startswith('{')),180)

    def test_repetitive_loot_and_slot_prose_are_compact(self):
        for q in self.after.values():
            self.assertFalse(any(s.startswith(('探索宝箱：','可能掉落：')) for s in q['description']))
            if q['target'].startswith('guide:slot_'):
                self.assertLess(sum(len(s) for s in q['description'] if not s.startswith('{')),140)

    def test_launcher_drift_is_rejected_without_writes(self):
        from tempfile import TemporaryDirectory
        from sync_quest_journey import check_baseline,digest
        with TemporaryDirectory() as folder:
            p=Path(folder)/'data.snbt';p.write_bytes(b'{original: true}')
            expected={'data.snbt':digest(p.read_bytes())}
            check_baseline(Path(folder),expected)
            p.write_bytes(b'{other_developer: true}')
            with self.assertRaisesRegex(AssertionError,'Launcher definitions changed'):
                check_baseline(Path(folder),expected)
            self.assertEqual(b'{other_developer: true}',p.read_bytes())

    def test_merged_chapter_number_does_not_survive_in_prose(self):
        q=self.after['10000000000a0005']
        self.assertIn('《四象试炼与讨伐》',' '.join(q['description']))
        self.assertNotIn('第 09 章',' '.join(q['description']))

    def test_wind_main_uses_normal_recipe_and_preserves_optional_event_detector(self):
        q=self.after['1000000000010026'];text=' '.join(q['description'])
        self.assertIn('普通羽毛×2',text);self.assertIn('丝绸×1',text)
        self.assertIn('符纸×1',text);self.assertIn('御风符×1',text)
        normal=json.loads((story.ROOT/'src/main/resources/data/dynasty/recipes/wind_talisman.json').read_text())
        self.assertEqual(['dynasty:talisman_paper','minecraft:feather','minecraft:feather','dynasty:silk'],
                         [i['item'] for i in normal['ingredients']])
        self.assertEqual(1,normal['result']['count'])
        self.assertEqual(self.before[q['id']]['deps'],q['deps'])
        rare=self.after['10d388e6188a3f8e']
        self.assertIn('可选',rare['title']);self.assertEqual('dynasty:xuanniao_shenyu',rare['target'])
        self.assertNotIn(rare['id'],q['deps'])
        materials=[self.after[journey.ident('wind-material:'+key)] for key in ('feather','silk','paper')]
        self.assertEqual(['minecraft:feather','dynasty:silk','dynasty:talisman_paper'],[m['target'] for m in materials])
        for i,m in enumerate(materials):
            self.assertEqual('item',m['kind'])
            self.assertEqual([materials[i-1]['id']] if i else q['deps'],m['deps'])

    def test_rare_feather_help_matches_event_conditions_and_probability(self):
        from quest_journey_help import source_hint
        cat=json.loads((story.ROOT/'src/main/resources/data/dynasty/world_events/catalog.json').read_text())
        event=next(e for e in cat if e['id']=='dynasty:xuanniao_zhige')
        text=source_hint('dynasty:xuanniao_shenyu')
        self.assertIn(str(event['minDistanceFromSpawn'])+'格',text)
        self.assertIn(str(event['radius'])+'格',text)
        self.assertEqual((0,12000),(event['startTime'],event['endTime']))
        self.assertIn('主世界白天',text)
        loot=json.loads((story.ROOT/'src/main/resources/data/dynasty/loot_tables/events/xuanniao_zhige.json').read_text())
        chance=loot['pools'][0]['conditions'][0]['chance']
        self.assertIn(str(round(chance*100))+'%',text);self.assertIn('非必出',text)
        manager=(story.ROOT/'src/main/java/com/dynasty/worldevent/DynastyWorldEventManager.java').read_text()
        kills=re.search(r'getInt\(KILLS\)>=(\d+)',manager)
        self.assertIn(kills[1]+'只敌对怪',text)
        celestial=manager.split('case CELESTIAL->{',1)[1].split('default->',1)[0]
        ticks=int(re.search(r'instance.started>=(\d+)',celestial)[1])
        self.assertIn(str(ticks//20)+'秒',text)

    def test_building_material_sources_and_altar_types_are_distinct(self):
        courtyard=(story.ROOT/'src/main/java/com/dynasty/structure/AcademyCourtyard.java').read_text()
        for short,symbol,qid in [('marble_block','MARBLE_BLOCK','1000000000000022'),
                                  ('crimson_pillar','CRIMSON_PILLAR','1000000000000024')]:
            self.assertIn('DynastyBlocks.'+symbol,courtyard)
            loot=json.loads((story.ROOT/f'src/main/resources/data/dynasty/loot_tables/blocks/{short}.json').read_text())
            self.assertEqual('dynasty:'+short,loot['pools'][0]['entries'][0]['name'])
            self.assertNotIn('silk_touch',json.dumps(loot))
            text=' '.join(self.after[qid]['description'])
            self.assertIn('书院',text);self.assertIn('无须精准采集',text)
            self.assertIn('academy_materials.png',text)
        altar=self.after['1000000000000027']
        self.assertIn('建筑装饰',altar['title'])
        self.assertIn('法阵·祭坛',' '.join(altar['description']))
        self.assertEqual('dynasty:altar',altar['target'])

    def test_acquisition_help_does_not_claim_crafting_or_manual_detection(self):
        for key in ('nature','explorer'):
            q=self.after[journey.ident('navigation:'+key)]
            self.assertIn('取得并持有',q['description'][0])
            self.assertNotIn('合成并持有',q['description'][0])
        for route in ('guard','sword','archer','talisman'):
            q=self.after[journey.ident('refining:'+route)]
            self.assertEqual('checkmark',q['kind'])
            self.assertIn('本页是阅读教程',' '.join(q['description']))

    def test_army_clear_prose_follows_serialized_detector_without_changing_cod6(self):
        from quest_cod6 import QUESTS
        for qid in QUESTS:
            q=self.after[qid];text=' '.join(s for s in q['description'] if not s.startswith('{'))
            self.assertIn('advancement: "dynasty:army_clear_',q['tasks'])
            self.assertEqual(self.before[qid]['tasks'],q['tasks'])
            self.assertEqual(self.before[qid]['deps'],q['deps'])
            self.assertIn('完成',q['description'][0]);self.assertIn('军阵关卡',q['description'][0])
            self.assertIn('募兵台',text);self.assertIn('关卡结算胜利',text)
            self.assertIn('野外击杀不算本节点',text)
            self.assertNotIn('自然生成',text);self.assertNotIn('亲自击败',text)
        army=(story.ROOT/'src/main/java/com/dynasty/army/ArmyEncounters.java').read_text()
        self.assertIn('"army_clear_"+id',army);self.assertIn('troops.isEmpty()',army)

    def test_brewing_filters_require_the_actual_potion_and_keep_legacy_identity(self):
        c=next(c for c in self.book if c['file']=='dynasty_c1')
        export=story.encode(c)
        qs=[self.after[journey.ident('brewing:'+key)] for key in ('stand','fuel','wart','water','awkward')]
        self.assertEqual(['minecraft:brewing_stand','minecraft:blaze_powder','minecraft:nether_wart','minecraft:potion','minecraft:potion'],[q['target'] for q in qs])
        for i,q in enumerate(qs):self.assertEqual([qs[i-1]['id']] if i else [],q['deps'])
        for q,expected in zip(qs[-2:],['minecraft:water','minecraft:awkward']):
            self.assertIn('tag: { Potion: "'+expected+'" }',q['tasks'])
            self.assertIn('match_nbt: true',q['tasks']);self.assertIn('weak_nbt_match: true',q['tasks'])
            self.assertIn(q['tasks'].split('item: ',1)[1].split(', count:',1)[0],export)
        legacy=self.after['100000000000002b']
        self.assertEqual(self.before[legacy['id']]['tasks'],legacy['tasks'])
        self.assertEqual(self.before[legacy['id']]['rewards'],legacy['rewards'])
        self.assertIn('可跳过',legacy['subtitle']);self.assertTrue(legacy['unverified_source'])

    def test_structure_visits_are_short_actionable_and_keep_actual_advancements(self):
        for qid in ('10000000000a0000','10000000000a0005','10000000000a0006'):
            q=self.after[qid];text=' '.join(s for s in q['description'] if not s.startswith('{'))
            self.assertEqual(self.before[qid]['tasks'],q['tasks'])
            self.assertIn('进入',q['description'][0]);self.assertIn('探险者指南针',text)
            self.assertNotIn('place',text);self.assertNotIn('dynasty:',text)
            self.assertLess(len(text),100)

    def test_accessory_upgrade_prose_preserves_effect_and_actual_recipe(self):
        selected=[q for q in self.after.values() if q.get('route') and q.get('subtitle')=='进阶饰品']
        expected=[q for q in self.before.values() if q.get('route') and q.get('subtitle')=='进阶饰品']
        self.assertEqual({q['id'] for q in expected},{q['id'] for q in selected})
        for q in selected:
            self.assertIn(q['purpose']+'。',q['description'])
            recipes=[s for s in q['description'] if '→' in s]
            self.assertEqual(1,len(recipes));self.assertIn('保留淬炼',' '.join(q['description']))
            self.assertLess(sum(len(s) for s in q['description'] if not s.startswith('{')),140)

if __name__=='__main__':unittest.main()
