package com.github.thedeathlycow.frostiful.tag;

import com.github.thedeathlycow.frostiful.Frostiful;
import net.minecraft.block.entity.BannerPattern;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;

public class FBannerPatternTags {

    public static final TagKey<BannerPattern> SNOWFLAKE_PATTERN_ITEM = key("pattern_item/snowflake");


    private static TagKey<BannerPattern> key(String id) {
        return TagKey.of(RegistryKeys.BANNER_PATTERN, Frostiful.id(id));
    }

}
