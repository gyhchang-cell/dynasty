package net.myriantics.klaxon.datagen.tag;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalEntityTypeTags;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.entity.EntityType;
import net.myriantics.klaxon.registry.entity.KlaxonEntityTypes;
import net.myriantics.klaxon.tag.klaxon.KlaxonEntityTypeTags;

import java.util.concurrent.CompletableFuture;

public class KlaxonEntityTypeTagProvider extends FabricTagProvider<EntityType<?>> {

    public KlaxonEntityTypeTagProvider(FabricDataOutput output, CompletableFuture<HolderLookup.Provider> registriesFuture) {
        super(output, Registries.ENTITY_TYPE, registriesFuture);
    }

    @Override
    protected void addTags(HolderLookup.Provider arg) {
        getOrCreateTagBuilder(KlaxonEntityTypeTags.HEAVY_HITTERS)
                .add(EntityType.VINDICATOR)
                .add(EntityType.PIGLIN_BRUTE)
                // haha funny fox bonk
                .add(EntityType.FOX)
                .add(EntityType.WITHER_SKELETON)
                .add(EntityType.ZOMBIFIED_PIGLIN);

        getOrCreateTagBuilder(KlaxonEntityTypeTags.WALLJUMP_MOVABLE_ENTITIES)
                .forceAddTag(ConventionalEntityTypeTags.MINECARTS);

        getOrCreateTagBuilder(KlaxonEntityTypeTags.GRAPPLE_CLAW_DRAGGABLE)
                .add(EntityType.ITEM)
                .add(EntityType.EXPERIENCE_ORB)
                .add(EntityType.EXPERIENCE_BOTTLE)
                .add(EntityType.SMALL_FIREBALL)
                .add(EntityType.ENDER_PEARL)
                .add(EntityType.EYE_OF_ENDER);

        // weight tags
        getOrCreateTagBuilder(KlaxonEntityTypeTags.HEAVY_ENTITIES)
                .forceAddTag(ConventionalEntityTypeTags.BOSSES)
                .forceAddTag(ConventionalEntityTypeTags.CAPTURING_NOT_SUPPORTED)
                .forceAddTag(ConventionalEntityTypeTags.TELEPORTING_NOT_SUPPORTED)
                .add(EntityType.SHULKER)
                .add(EntityType.IRON_GOLEM)
                .add(EntityType.RAVAGER)
                .add(EntityType.ENDER_DRAGON)
                .add(EntityType.WITHER)
                .add(EntityType.GIANT)
                .add(EntityType.WARDEN)
                .add(EntityType.AREA_EFFECT_CLOUD);
        getOrCreateTagBuilder(KlaxonEntityTypeTags.LIGHT_ENTITIES)
                .forceAddTag(EntityTypeTags.POWDER_SNOW_WALKABLE_MOBS)
                .forceAddTag(EntityTypeTags.SKELETONS)
                .add(EntityType.SNOW_GOLEM)
                .add(EntityType.GHAST)
                .add(EntityType.ITEM)
                .add(EntityType.ENDER_PEARL)
                .add(EntityType.EYE_OF_ENDER);

        // allow / denylist tags
        getOrCreateTagBuilder(KlaxonEntityTypeTags.GRAPPLE_WINCH_IMMOVABLE_DIRECT_MOUNTS)
                .addOptionalTag(ConventionalEntityTypeTags.BOATS);
        getOrCreateTagBuilder(KlaxonEntityTypeTags.GRAPPLE_CLAW_GENTLY_HOOKED_ENTITIES)
                .forceAddTag(ConventionalEntityTypeTags.BOATS)
                .forceAddTag(ConventionalEntityTypeTags.MINECARTS)
                .add(EntityType.ITEM_FRAME)
                .add(EntityType.GLOW_ITEM_FRAME)
                .add(EntityType.ARMOR_STAND);
        getOrCreateTagBuilder(KlaxonEntityTypeTags.GRAPPLE_CLAW_HOOKING_DENYLIST)
                .add(EntityType.ENDERMAN);
        getOrCreateTagBuilder(KlaxonEntityTypeTags.GRAPPLE_CLAW_COLLISION_DENYLIST)
                .forceAddTag(KlaxonEntityTypeTags.GRAPPLE_CLAW_DRAGGABLE);

        getOrCreateTagBuilder(EntityTypeTags.IMPACT_PROJECTILES)
                .add(KlaxonEntityTypes.GRAPPLE_CLAW.value());
    }
}
