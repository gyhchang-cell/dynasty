package net.myriantics.klaxon.datagen.recipe;

import net.fabricmc.fabric.api.resource.conditions.v1.ResourceCondition;
import net.minecraft.data.recipes.RecipeOutput;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.myriantics.klaxon.datagen.NamedIngredient;
import net.myriantics.klaxon.registry.item.KlaxonItems;

public class KlaxonOreProcessingRecipeProvider extends KlaxonRecipeSubProvider{

    public KlaxonOreProcessingRecipeProvider(KlaxonRecipeProvider provider, RecipeOutput exporter) {
        super(provider, exporter);
    }

    @Override
    public void generateRecipes() {
        buildFracturedOreProcessingRecipes();
    }

    private void buildFracturedOreProcessingRecipes() {
        addFracturedOreProcessingRecipes(KlaxonItems.FRACTURED_RAW_IRON.value(), Items.RAW_IRON, KlaxonItems.FRACTURED_IRON.value(), Items.IRON_INGOT);
        addFracturedOreProcessingRecipes(KlaxonItems.FRACTURED_RAW_GOLD.value(), Items.RAW_GOLD, KlaxonItems.FRACTURED_GOLD.value(), Items.GOLD_INGOT);
        addFracturedOreProcessingRecipes(KlaxonItems.FRACTURED_RAW_COPPER.value(), Items.RAW_COPPER, KlaxonItems.FRACTURED_COPPER.value(), Items.COPPER_INGOT);
    }

    public void addFracturedOreProcessingRecipes(Item fracturedRawOreItem, Item rawOreItem, Item fracturedOreFragmentsItem, Item oreIngotItem,
                                                 final ResourceCondition... conditions) {
        // blast processing
        addBlastProcessingRecipe(NamedIngredient.ofItems(rawOreItem), 0.4f, 1.4f,
                builder -> builder
                        .guaranteed(new ItemStack(fracturedRawOreItem))
                        .chance(new ItemStack(fracturedRawOreItem), 1d/3),
                conditions
        );
        addBlastProcessingRecipe(NamedIngredient.ofItems(oreIngotItem), 0.5f, 1.7f,
                builder -> builder
                        .guaranteed(new ItemStack(fracturedOreFragmentsItem))
                        .chance(new ItemStack(fracturedOreFragmentsItem), 1d/3),
                conditions
        );

        // smelting
        addBlastingAndSmeltingRecipe(Ingredient.of(fracturedRawOreItem), new ItemStack(fracturedOreFragmentsItem), 1.0f, 150, null, "fractured_ores", conditions);

        // crafting
        add2x2PackingRecipe(Ingredient.of(fracturedRawOreItem), new ItemStack(rawOreItem), null, null, conditions);
        add2x2PackingRecipe(Ingredient.of(fracturedOreFragmentsItem), new ItemStack(oreIngotItem), null, null, conditions);
    }
}
