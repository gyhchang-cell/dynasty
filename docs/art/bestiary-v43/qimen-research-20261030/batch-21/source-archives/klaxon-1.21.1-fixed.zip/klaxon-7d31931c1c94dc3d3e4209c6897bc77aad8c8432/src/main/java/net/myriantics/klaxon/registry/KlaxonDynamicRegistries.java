package net.myriantics.klaxon.registry;

import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.event.registry.DynamicRegistries;
import net.minecraft.core.Registry;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceKey;
import net.myriantics.klaxon.KlaxonCommon;
import net.myriantics.klaxon.mechanics.explosive_catalyst.ExplosiveCatalystBehavior;
import net.myriantics.klaxon.mechanics.explosive_catalyst.definition.ExplosiveCatalystDefinition;
import net.myriantics.klaxon.mechanics.grapple_winch.VeinmineGroup;
import net.myriantics.klaxon.mechanics.wrench.WrenchInteractionDenialPredicate;
import net.myriantics.klaxon.recipe.tool_usage.ToolUsageRecipeType;

public abstract class KlaxonDynamicRegistries {

    static {
        registerSynced(KlaxonRegistries.TOOL_USAGE_RECIPE_TYPE, ToolUsageRecipeType.CODEC, DynamicRegistries.SyncOption.SKIP_WHEN_EMPTY);
        registerSynced(KlaxonRegistries.VEINMINE_GROUP, VeinmineGroup.CODEC, DynamicRegistries.SyncOption.SKIP_WHEN_EMPTY);
        registerSynced(KlaxonRegistries.WRENCH_INTERACTION_DENIAL_PREDICATE, WrenchInteractionDenialPredicate.CODEC, DynamicRegistries.SyncOption.SKIP_WHEN_EMPTY);
        registerSynced(KlaxonRegistries.EXPLOSIVE_CATALYST_BEHAVIOR, ExplosiveCatalystBehavior.CODEC, DynamicRegistries.SyncOption.SKIP_WHEN_EMPTY);
        registerSynced(KlaxonRegistries.EXPLOSIVE_CATALYST_DEFINITION, ExplosiveCatalystDefinition.CODEC, DynamicRegistries.SyncOption.SKIP_WHEN_EMPTY);
    }

    private static <T> void registerSynced(ResourceKey<? extends Registry<T>> key, Codec<T> codec, DynamicRegistries.SyncOption... options) {
        DynamicRegistries.registerSynced(key, codec, options);
    }

    public static void init() {
        KlaxonCommon.LOGGER.info("Registered KLAXON's Dynamic Registries!");
    }
}
