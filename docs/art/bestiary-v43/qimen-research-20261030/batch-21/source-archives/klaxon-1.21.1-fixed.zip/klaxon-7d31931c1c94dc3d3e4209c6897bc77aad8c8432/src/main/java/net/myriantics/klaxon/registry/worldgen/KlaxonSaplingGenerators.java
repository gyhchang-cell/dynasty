package net.myriantics.klaxon.registry.worldgen;

import net.minecraft.world.level.block.grower.TreeGrower;
import net.myriantics.klaxon.KlaxonCommon;
import net.myriantics.klaxon.block.functional.hallnox_pod.DirectionalSaplingGenerator;
import net.myriantics.klaxon.datagen.KlaxonFeatureProvider;

import java.util.Optional;

public abstract class KlaxonSaplingGenerators {
    public static final TreeGrower EMPTY = new TreeGrower(
            "empty",
            0.0f,
            Optional.empty(),
            Optional.empty(),
            Optional.empty(),
            Optional.empty(),
            Optional.empty(),
            Optional.empty()
    );

    public static final DirectionalSaplingGenerator HALLNOX = new DirectionalSaplingGenerator(
            "hallnox",
            Optional.of(KlaxonFeatureProvider.UPRIGHT_DRY_HALLNOX_GROWTH),
            Optional.of(KlaxonFeatureProvider.DOWNRIGHT_HALLNOX_GROWTH),
            Optional.of(KlaxonFeatureProvider.NORTH_HORIZONTAL_HALLNOX_GROWTH),
            Optional.of(KlaxonFeatureProvider.EAST_HORIZONTAL_HALLNOX_GROWTH),
            Optional.of(KlaxonFeatureProvider.SOUTH_HORIZONTAL_HALLNOX_GROWTH),
            Optional.of(KlaxonFeatureProvider.WEST_HORIZONTAL_HALLNOX_GROWTH)
    );

    public static void init() {
        KlaxonCommon.LOGGER.info("Registered KLAXON's Sapling Generators!");
    }
}
