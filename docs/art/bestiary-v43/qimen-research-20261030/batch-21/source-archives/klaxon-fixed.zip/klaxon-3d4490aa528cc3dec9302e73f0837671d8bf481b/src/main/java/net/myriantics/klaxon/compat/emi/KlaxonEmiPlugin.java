package net.myriantics.klaxon.compat.emi;

import dev.emi.emi.api.EmiPlugin;
import dev.emi.emi.api.EmiRegistry;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.recipe.*;
import net.minecraft.util.Identifier;
import net.myriantics.klaxon.KlaxonCommon;
import net.myriantics.klaxon.api.behavior.BlastProcessorBehavior;
import net.myriantics.klaxon.registry.KlaxonBlocks;
import net.myriantics.klaxon.block.customblocks.blast_processor.deepslate.DeepslateBlastProcessorBlock;
import net.myriantics.klaxon.compat.emi.recipes.BlastProcessingEmiRecipe;
import net.myriantics.klaxon.compat.emi.recipes.HammeringEmiRecipe;
import net.myriantics.klaxon.compat.emi.recipes.ItemExplosionPowerEmiInfoRecipe;
import net.myriantics.klaxon.compat.emi.recipes.KlaxonEMIAnvilRecipe;
import net.myriantics.klaxon.registry.KlaxonRecipeTypes;
import net.myriantics.klaxon.recipe.item_explosion_power.ItemExplosionPowerRecipe;
import net.myriantics.klaxon.tag.klaxon.KlaxonItemTags;

import java.util.Random;
import java.util.function.Function;

// spectrum's emi plugin used as reference
public class KlaxonEmiPlugin implements EmiPlugin {

    public static final Random RANDOM = new Random();

    @Override
    public void register(EmiRegistry registry) {
        RecipeManager manager = registry.getRecipeManager();

        registerCategories(registry);
        registerRecipes(registry);
    }

    private void registerCategories(EmiRegistry registry) {
        registry.addCategory(KlaxonEmiRecipeCategories.HAMMERING);
        registry.addCategory(KlaxonEmiRecipeCategories.BLAST_PROCESSING);
        registry.addCategory(KlaxonEmiRecipeCategories.ITEM_EXPLOSION_POWER);

        registry.addWorkstation(KlaxonEmiRecipeCategories.BLAST_PROCESSING, EmiStack.of(KlaxonBlocks.DEEPSLATE_BLAST_PROCESSOR));
        registry.addWorkstation(KlaxonEmiRecipeCategories.ITEM_EXPLOSION_POWER, EmiStack.of(KlaxonBlocks.DEEPSLATE_BLAST_PROCESSOR));
    }

    private void registerRecipes(EmiRegistry registry) {
        addAll(registry, KlaxonRecipeTypes.HAMMERING, HammeringEmiRecipe::new);
        addAllConditional(registry, KlaxonRecipeTypes.ITEM_EXPLOSION_POWER, ItemExplosionPowerEmiInfoRecipe::new);
        addBlastProcessorBehaviorItemExplosionPowerRecipes(registry);
        addAll(registry, KlaxonRecipeTypes.BLAST_PROCESSING, (recipe) -> new BlastProcessingEmiRecipe(recipe, registry, recipe.getId()));
        registerMiscRecipes(registry);
    }

    private void registerMiscRecipes(EmiRegistry registry) {
        registry.addRecipe(new KlaxonEMIAnvilRecipe(EmiStack.of(Items.FLINT_AND_STEEL), EmiIngredient.of(KlaxonItemTags.CRUDE_INCLUSIVE_STEEL_NUGGETS), "flint_and_steel"));
    }

    public <C extends Recipe<Inventory>> void addAll(EmiRegistry registry, RecipeType<C> type, Function<C, EmiRecipe> constructor) {
        for (C recipeEntry : registry.getRecipeManager().listAllOfType(type)) {
            registry.addRecipe(constructor.apply(recipeEntry));
        }
    }

    public <C extends Recipe<Inventory>> void addAllConditional(EmiRegistry registry, RecipeType<C> type, Function<C, EmiRecipe> constructor) {
        for (C recipeEntry : registry.getRecipeManager().listAllOfType(type)) {

            // dont show hidden recipes
            if (recipeEntry instanceof ItemExplosionPowerRecipe itemExplosionPowerRecipe) {
                if (!itemExplosionPowerRecipe.isHidden()) {
                    registry.addRecipe(constructor.apply(recipeEntry));
                }
            }
        }
    }

    public void addBlastProcessorBehaviorItemExplosionPowerRecipes(EmiRegistry registry) {
        for (Item entry : DeepslateBlastProcessorBlock.BEHAVIORS.keySet()) {
            BlastProcessorBehavior behavior = DeepslateBlastProcessorBlock.BEHAVIORS.get(entry);
            BlastProcessorBehavior.BlastProcessorBehaviorItemExplosionPowerEmiDataCompound data = behavior.getEmiData();

            // only add the recipe if the behavior actually passes in the data
            if (data != null) {
                registry.addRecipe(new ItemExplosionPowerEmiInfoRecipe(
                        Ingredient.ofItems(entry),
                        data.explosionPowerMin(),
                        data.explosionPowerMax(),
                        data.infoText(),
                        // append entry id to recipe id to prevent duplicate entries
                        KlaxonCommon.locate("/bp_behavior_item_explosion_power/" + entry.toString())
                        )
                );
            }
        }
    }
}
