package net.myriantics.klaxon.recipe.makeshift_crafting.shapeless;

import net.minecraft.inventory.RecipeInputInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.recipe.ShapelessRecipe;
import net.minecraft.recipe.book.CraftingRecipeCategory;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.Identifier;
import net.minecraft.util.collection.DefaultedList;
import net.myriantics.klaxon.KlaxonCommon;
import net.myriantics.klaxon.recipe.makeshift_crafting.MakeshiftCraftingRecipe;
import net.myriantics.klaxon.registry.KlaxonRecipeTypes;
import net.myriantics.klaxon.tag.klaxon.KlaxonItemTags;

import java.util.List;

public class MakeshiftShapelessCraftingRecipe extends ShapelessRecipe implements MakeshiftCraftingRecipe {

    private final ItemStack result;
    List<Ingredient> constantIngredients;
    DefaultedList<Ingredient> ingredients;

    public MakeshiftShapelessCraftingRecipe(Identifier id, String group, CraftingRecipeCategory category, ItemStack result, DefaultedList<Ingredient> ingredients, List<Ingredient> constantIngredients) {
        super(id, group, category, result, ingredients);
        this.constantIngredients = constantIngredients;
        this.ingredients = ingredients;
        this.result = result;
    }

    @Override
    public ItemStack craft(RecipeInputInventory craftingRecipeInput, DynamicRegistryManager registryManager) {
        List<ItemStack> inputStacks = craftingRecipeInput.getInputStacks();

        ItemStack result = this.getOutput(registryManager);

        final double durabilityPenaltyCap = 0.5;
        int totalPresentMakeshiftIngredients = 0;
        int totalPotentialMakeshiftIngredients = 0;

        for (ItemStack inputStack : inputStacks) {

            // checks to see if the marked ingredient has been indicated to have a makeshift replacement
            if (this.constantIngredients.stream().noneMatch((ingredient -> ingredient.test(inputStack))) && !inputStack.isEmpty()) {
                totalPotentialMakeshiftIngredients++;

                totalPresentMakeshiftIngredients += inputStack.isIn(KlaxonItemTags.MAKESHIFT_CRAFTING_INGREDIENTS) ? 1 : 0;
            }
        }

        // decrease the result's durability according to how many makeshift stacks were used in crafting out of all potential makeshift ingredients in the recipe
        result.setDamage((int) (result.getMaxDamage() * durabilityPenaltyCap * ((double) totalPresentMakeshiftIngredients / totalPotentialMakeshiftIngredients)));

        return result.copy();
    }

    public ItemStack getRawResult() {
        return result;
    }

    public List<Ingredient> getConstantIngredients() {
        return constantIngredients;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return KlaxonRecipeTypes.MAKESHIFT_SHAPELESS_CRAFTING_RECIPE_SERIALIZER;
    }
}
