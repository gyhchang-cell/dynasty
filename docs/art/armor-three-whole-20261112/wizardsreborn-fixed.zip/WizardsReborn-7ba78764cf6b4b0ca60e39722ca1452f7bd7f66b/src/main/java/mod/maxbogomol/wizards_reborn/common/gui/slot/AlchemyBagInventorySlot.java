package mod.maxbogomol.wizards_reborn.common.gui.slot;

import mod.maxbogomol.wizards_reborn.common.item.equipment.curio.AlchemyBagItem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.SlotItemHandler;

public class AlchemyBagInventorySlot extends SlotItemHandler {

    public AlchemyBagInventorySlot(IItemHandler itemHandler, int slot, int xPosition, int yPosition) {
        super(itemHandler, slot, xPosition, yPosition);
    }

    @Override
    public boolean mayPlace(ItemStack stack) {
        return !(getItem().getItem() instanceof AlchemyBagItem);
    }

    @Override
    public boolean mayPickup(Player player) {
        return !(getItem().getItem() instanceof AlchemyBagItem);
    }
}
