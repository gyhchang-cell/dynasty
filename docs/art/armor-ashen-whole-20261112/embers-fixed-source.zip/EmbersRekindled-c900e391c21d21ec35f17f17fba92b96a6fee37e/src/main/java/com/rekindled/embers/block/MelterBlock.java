package com.rekindled.embers.block;

import com.rekindled.embers.RegistryManager;
import com.rekindled.embers.blockentity.MelterBottomBlockEntity;
import com.rekindled.embers.blockentity.MelterTopBlockEntity;
import com.rekindled.embers.util.Misc;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.fluids.FluidUtil;
import net.minecraftforge.fluids.capability.IFluidHandler;

public class MelterBlock extends DoubleTallMachineBlock {

	protected static final VoxelShape BASE_AABB = Shapes.or(Block.box(2,0,2,14,16,14), Block.box(0,8,0,4,16,4), Block.box(0,8,12,4,16,16), Block.box(12,8,0,16,16,4), Block.box(12,8,12,16,16,16), Block.box(1,0,1,4,8,4), Block.box(1,0,12,4,8,15), Block.box(12,0,1,15,8,4), Block.box(12,0,12,15,8,15));
	protected static final VoxelShape BASE_INTERACTION = Shapes.or(Block.box(1,0,1,15,8,15),Block.box(0,8,0,16,16,16));
	protected static final VoxelShape TOP_AABB = Shapes.or(Block.box(0,0,0,4,16,4),Block.box(6,0,0,10,16,4),Block.box(12,0,0,16,16,4),Block.box(12,0,6,16,16,10),Block.box(12,0,12,16,16,16),Block.box(6,0,12,10,16,16),Block.box(0,0,12,4,16,16),Block.box(0,0,6,4,16,10),Block.box(4,1,2,6,15,4),Block.box(10,1,2,12,15,4),Block.box(12,1,4,14,15,6),Block.box(12,1,10,14,15,12),Block.box(10,1,12,12,15,14),Block.box(4,1,12,6,15,14),Block.box(2,1,10,4,15,12),Block.box(2,1,4,4,15,6),Block.box(3,0,13,13,2,15),Block.box(3,0,1,13,2,3),Block.box(13,0,3,15,2,13),Block.box(1,0,3,3,2,13));

	public MelterBlock(Properties properties, SoundType topSound) {
		super(properties, topSound);
	}

	@Override
	public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
		if (state.getValue(BlockStateProperties.DOUBLE_BLOCK_HALF) != DoubleBlockHalf.LOWER && level.getBlockEntity(pos) instanceof MelterTopBlockEntity melterEntity) {
			ItemStack heldItem = player.getItemInHand(hand);
			if (!heldItem.isEmpty()) {
				IFluidHandler cap = melterEntity.getCapability(ForgeCapabilities.FLUID_HANDLER, hit.getDirection()).orElse(null);
				if (cap != null && FluidUtil.interactWithFluidHandler(player, hand, cap)) {
					return InteractionResult.SUCCESS;
				}
			}
			return Misc.useItemOnInventory(melterEntity.inventory, level, player, hand);
		}
		return InteractionResult.PASS;
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
		return state.getValue(BlockStateProperties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.LOWER ? BASE_AABB : TOP_AABB;
	}

	@Override
	public VoxelShape getInteractionShape(BlockState state, BlockGetter level, BlockPos pos) {
		return state.getValue(BlockStateProperties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.LOWER ? BASE_INTERACTION : Shapes.block();
	}

	@Override
	public BlockEntity newBlockEntity(BlockPos pPos, BlockState pState) {
		if (pState.getValue(BlockStateProperties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.LOWER)
			return RegistryManager.MELTER_BOTTOM_ENTITY.get().create(pPos, pState);
		return RegistryManager.MELTER_TOP_ENTITY.get().create(pPos, pState);
	}

	@Override
	public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level pLevel, BlockState pState, BlockEntityType<T> pBlockEntityType) {
		if (pState.getValue(BlockStateProperties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.LOWER)
			return pLevel.isClientSide ? createTickerHelper(pBlockEntityType, RegistryManager.MELTER_BOTTOM_ENTITY.get(), MelterBottomBlockEntity::clientTick) : createTickerHelper(pBlockEntityType, RegistryManager.MELTER_BOTTOM_ENTITY.get(), MelterBottomBlockEntity::serverTick);
		return pLevel.isClientSide ? createTickerHelper(pBlockEntityType, RegistryManager.MELTER_TOP_ENTITY.get(), MelterTopBlockEntity::clientTick) : createTickerHelper(pBlockEntityType, RegistryManager.MELTER_TOP_ENTITY.get(), MelterTopBlockEntity::serverTick);
	}
}
