package net.merchantpug.apugli.power;

import com.google.auto.service.AutoService;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import net.merchantpug.apugli.power.configuration.FabricValueModifyingConfiguration;
import net.merchantpug.apugli.power.factory.ModifyEnchantmentLevelPowerFactory;
import net.merchantpug.apugli.util.ComparableItemStack;
import net.minecraft.nbt.ListTag;
import net.minecraft.util.Tuple;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

import java.util.concurrent.ConcurrentHashMap;

@AutoService(ModifyEnchantmentLevelPowerFactory.class)
public class ModifyEnchantmentLevelPower extends AbstractValueModifyingPower implements ModifyEnchantmentLevelPowerFactory<ConfiguredPower<FabricValueModifyingConfiguration, ?>> {
    private static final ConcurrentHashMap<LivingEntity, ConcurrentHashMap<ComparableItemStack, ListTag>> ENTITY_ITEM_ENCHANTS = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<LivingEntity, ConcurrentHashMap<ConfiguredPower<FabricValueModifyingConfiguration, ?>, Tuple<Integer, Boolean>>> POWER_MODIFIER_CACHE = new ConcurrentHashMap<>();

    public ModifyEnchantmentLevelPower() {
        super(ModifyEnchantmentLevelPowerFactory.getSerializableData().xmap(
                FabricValueModifyingConfiguration::new,
                FabricValueModifyingConfiguration::data
        ).codec());
    }

    @Override
    public void onAdded(ConfiguredPower<FabricValueModifyingConfiguration, ?> configuration, Entity entity) {
        ModifyEnchantmentLevelPowerFactory.super.onAdded(configuration, entity);
    }

    @Override
    public void onRemoved(ConfiguredPower<FabricValueModifyingConfiguration, ?> configuration, Entity entity) {
        ModifyEnchantmentLevelPowerFactory.super.onRemoved(configuration, entity);
    }

    @Override
    public ConcurrentHashMap<LivingEntity, ConcurrentHashMap<ComparableItemStack, ListTag>> getEntityItemEnchants() {
        return ENTITY_ITEM_ENCHANTS;
    }

    @Override
    public ConcurrentHashMap<LivingEntity, ConcurrentHashMap<ConfiguredPower<FabricValueModifyingConfiguration, ?>, Tuple<Integer, Boolean>>> getPowerModifierCache() {
        return POWER_MODIFIER_CACHE;
    }

}
