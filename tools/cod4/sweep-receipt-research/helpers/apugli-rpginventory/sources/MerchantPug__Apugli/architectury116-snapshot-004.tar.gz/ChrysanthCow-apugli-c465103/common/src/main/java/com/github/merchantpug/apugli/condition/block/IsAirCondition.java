package com.github.merchantpug.apugli.condition.block;

import com.github.merchantpug.apugli.Apugli;
import io.github.apace100.origins.power.factory.condition.ConditionFactory;
import io.github.apace100.origins.util.SerializableData;
import net.minecraft.block.pattern.CachedBlockPosition;

public class IsAirCondition {
    public static boolean condition(SerializableData.Instance data, CachedBlockPosition block) {
        return block.getBlockState().isAir();
    }

    public static ConditionFactory<CachedBlockPosition> getFactory() {
        return new ConditionFactory<>(Apugli.identifier("air"), new SerializableData(),
                IsAirCondition::condition
        );
    }
}
