advancement revoke @s only oszu_fd:damage/damage_37.7

scoreboard players set @s oszu_fd_damage_delt 377

function oszu_fd:modifiers/check_modifiers
