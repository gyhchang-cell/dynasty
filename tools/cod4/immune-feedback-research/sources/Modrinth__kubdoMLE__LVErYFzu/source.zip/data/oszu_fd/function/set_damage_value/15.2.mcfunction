advancement revoke @s only oszu_fd:damage/damage_15.2

scoreboard players set @s oszu_fd_damage_delt 152

function oszu_fd:modifiers/check_modifiers
