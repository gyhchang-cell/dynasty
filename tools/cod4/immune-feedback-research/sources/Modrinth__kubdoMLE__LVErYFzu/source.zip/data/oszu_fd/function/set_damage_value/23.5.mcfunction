advancement revoke @s only oszu_fd:damage/damage_23.5

scoreboard players set @s oszu_fd_damage_delt 235

function oszu_fd:modifiers/check_modifiers
