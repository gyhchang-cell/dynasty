advancement revoke @s only oszu_fd:damage/damage_29.3

scoreboard players set @s oszu_fd_damage_delt 293

function oszu_fd:modifiers/check_modifiers
