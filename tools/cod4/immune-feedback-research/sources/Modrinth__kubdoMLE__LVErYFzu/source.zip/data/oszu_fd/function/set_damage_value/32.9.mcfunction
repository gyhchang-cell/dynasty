advancement revoke @s only oszu_fd:damage/damage_32.9

scoreboard players set @s oszu_fd_damage_delt 329

function oszu_fd:modifiers/check_modifiers
