advancement revoke @s only oszu_fd:damage/damage_51.9

scoreboard players set @s oszu_fd_damage_delt 519

function oszu_fd:modifiers/check_modifiers
