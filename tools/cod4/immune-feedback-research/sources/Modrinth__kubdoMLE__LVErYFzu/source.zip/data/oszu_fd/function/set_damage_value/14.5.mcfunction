advancement revoke @s only oszu_fd:damage/damage_14.5

scoreboard players set @s oszu_fd_damage_delt 145

function oszu_fd:modifiers/check_modifiers
