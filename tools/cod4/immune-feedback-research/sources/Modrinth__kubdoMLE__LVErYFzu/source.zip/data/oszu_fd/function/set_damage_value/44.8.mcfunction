advancement revoke @s only oszu_fd:damage/damage_44.8

scoreboard players set @s oszu_fd_damage_delt 448

function oszu_fd:modifiers/check_modifiers
