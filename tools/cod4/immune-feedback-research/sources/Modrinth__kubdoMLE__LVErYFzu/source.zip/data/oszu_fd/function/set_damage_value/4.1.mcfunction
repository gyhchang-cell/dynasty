advancement revoke @s only oszu_fd:damage/damage_4.1

scoreboard players set @s oszu_fd_damage_delt 41

function oszu_fd:modifiers/check_modifiers
